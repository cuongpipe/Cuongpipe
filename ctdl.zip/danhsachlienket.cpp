#include <iostream>
using namespace std;

struct Node {
    int data;         // Dữ liệu của node
    struct Node* next; // Con trỏ trỏ đến node tiếp theo
};

typedef struct Node* node;  // Alias cho con trỏ tới Node

// Hàm tạo một node mới
node indanhsach(int value) {
    node newNode = new Node;   // Cấp phát bộ nhớ cho node mới
    newNode->data = value;     // Gán giá trị cho dữ liệu node
    newNode->next = nullptr;   // Gán con trỏ next là nullptr (ban đầu node này là cuối cùng)
    return newNode;            // Trả về con trỏ node
}

// Hàm thêm node vào danh sách
void themNodeVaoCuoi(node &head, int value) {
    node newNode = indanhsach(value);
    if (head == nullptr) {
        head = newNode;  // Nếu danh sách rỗng, node mới trở thành head
    } else {
        node temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;  // Di chuyển tới node cuối cùng
        }
        temp->next = newNode;  // Gắn node mới vào cuối danh sách
    }
}

// Hàm in danh sách liên kết
void inDanhSach(node head) {
    node temp = head;
    while (temp != nullptr) {
        cout << temp->data << " -> ";
        temp = temp->next;  // Di chuyển đến node tiếp theo
    }
    cout << "NULL" << endl;  // In ra khi kết thúc danh sách
}

int main() {
    node head = nullptr;  // Khởi tạo danh sách rỗng

    themNodeVaoCuoi(head, 10);
    themNodeVaoCuoi(head, 20);
    themNodeVaoCuoi(head, 30);

    inDanhSach(head);  // In danh sách

    return 0;
}
