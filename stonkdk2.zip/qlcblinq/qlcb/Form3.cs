﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static qlcb.Form2;
using static qlcb.Form3;

namespace qlcb
{
    public partial class Form3: Form
    {
        public Form3()
        {
            InitializeComponent();
            LoadcbData();
        }
        //SqlConnection conn = new SqlConnection("Data Source=DESKTOP-ESUFOTK;Initial Catalog=qlcb;Integrated Security=True");
        //string query = "SELECT MaSo, HoTen,LuongCuaCanBo =( HeSoLuong *25000) from CanBo";
        //try
        //    {
        // conn.Open();
        // SqlCommand cmd = new SqlCommand(query, conn);
        //SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //adapter.Fill(dt);
        //    dataGridView3.DataSource = dt;
        //}
        //catch
        //    {
        //  MessageBox.Show("Lỗi kết nối database");
        //    }


        //Data Source = xr; Initial Catalog = qlcb; Integrated Security = True; Trust Server Certificate=True

        //bảng cán bộ
        [Table(Name = "CanBo")]
        public class CanBo
        {
            [Column(IsPrimaryKey = true)]
            public int MaSo { get; set; }

            [Column]
            public string HoTen { get; set; }

            [Column]
            public int MaDonVi { get; set; }

            [Column]
            public int MaNgach { get; set; }

            [Column]
            public DateTime NgaySinh { get; set; }

            [Column]
            public string GioiTinh { get; set; }

            [Column]
            public double HeSoLuong { get; set; }
        }


        public class QLCBDataContext : DataContext
        {
            public QLCBDataContext(string connection) : base(connection) { }
            public Table<CanBo> CanBos;

        }




        public void LoadcbData()
        {
            string connStr = @"Data Source=XR;Initial Catalog=qlcb;Integrated Security=True";
            QLCBDataContext db = new QLCBDataContext(connStr);
            ///string query = "SELECT MaSo, HoTen,LuongCuaCanBo =( HeSoLuong *25000) from CanBo";
            try
            {
                var results = from cb in db.CanBos 
                              select new
                              {
                                  cb.MaSo,
                                  cb.HoTen,
                                  cb.NgaySinh,
                                  cb.GioiTinh,
                                  LuongCuaCanBo = (cb.HeSoLuong * 25000)
                              };

                grid_luong.RowHeadersVisible = false;
                grid_luong.DataSource = results.ToList();
               // LoadComboBoxMaSo();

                //SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                //adapter.Fill(dt);
                //grid_luong.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối database: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

    }
}
