#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <stack>
using namespace std;

#define MAX_VERTICES 100
#define INF 1000

struct AdjList {
    int adjVertex;
    float weight;
    AdjList* next;
};

struct AdjListGraph {
    int numVertices;
    AdjList* adjList[MAX_VERTICES];
};

// a) Đọc đồ thị từ tệp (Graph4.txt - danh sách kề)
void readGraphFromFileGraph4(AdjListGraph& graph, string fileName) {
    ifstream file(fileName);
    file >> graph.numVertices;
    for (int i = 0; i < graph.numVertices; i++) {
        graph.adjList[i] = nullptr;
        for (int j = 0; j < graph.numVertices; j++) {
            float weight;
            file >> weight;
            if (weight != INF) {
                AdjList* newNode = new AdjList{ j, weight, graph.adjList[i] };
                graph.adjList[i] = newNode;
            }
        }
    }
    file.close();
}

// b) Đọc đồ thị từ tệp (Graph5.txt - ma trận kề)
void readGraphFromFileGraph5(AdjListGraph& graph, string fileName) {
    ifstream file(fileName);
    file >> graph.numVertices;
    for (int i = 0; i < graph.numVertices; i++) {
        graph.adjList[i] = nullptr;
    }

    vector<vector<int>> matrix(graph.numVertices, vector<int>(graph.numVertices, INF));

    // Đọc ma trận kề từ tệp
    for (int i = 0; i < graph.numVertices; i++) {
        for (int j = 0; j < graph.numVertices; j++) {
            file >> matrix[i][j];
            if (matrix[i][j] != INF) {
                AdjList* newNode = new AdjList{ j, matrix[i][j], graph.adjList[i] };
                graph.adjList[i] = newNode;
            }
        }
    }
    file.close();
}

// c) In đồ thị
void printGraph(AdjListGraph graph) {
    cout << "Num of vertices: " << graph.numVertices << endl;
    for (int i = 0; i < graph.numVertices; i++) {
        cout << "adjList[" << i << "]: ";
        for (AdjList* p = graph.adjList[i]; p != nullptr; p = p->next) {
            cout << p->adjVertex << "(" << p->weight << ") ";
        }
        cout << endl;
}

// Các hàm khác (BFS, DFS, kiểm tra liên thông, tìm đường đi, v.v.) sẽ giữ nguyên như trong mã trước
// ...

// Hàm main
int main() {
    AdjListGraph g;
    int choice;
    
    cout << "Chon loai do thi (1: Graph4.txt, 2: Graph5.txt): ";
    cin >> choice;

    // Đọc đồ thị dựa trên lựa chọn của người dùng
    if (choice == 1) {
        readGraphFromFileGraph4(g, "Graph4.txt");
        cout << "Da doc do thi tu Graph4.txt (Danh sach ke)." << endl;
    } else if (choice == 2) {
        readGraphFromFileGraph5(g, "Graph5.txt");
        cout << "Da doc do thi tu Graph5.txt (Ma tran ke)." << endl;
    } else {
        cout << "Chon khong hop le!" << endl;
        return 1;
    }

    printGraph(g);

    int s, d;
    cout << "Nhap dinh bat dau: ";
    cin >> s;
    cout << "Nhap dinh dich: ";
    cin >> d;

    int parent[MAX_VERTICES];
    PathBFS(g, s, parent);
    cout << "Duong di BFS tu " << s << " den " << d << ": ";
    printPath(parent, s, d);
    cout << endl;

    pathDFS(g, s, d, parent);
    cout << "Duong di DFS tu " << s << " den " << d << ": ";
    printPath(parent, s, d);
    cout << endl;

    int avoid;
    cout << "Nhap dinh can tranh: ";
    cin >> avoid;
    vector<int> path1 = pathNoVertex(g, s, d, avoid);
    cout << "Duong di tranh dinh " << avoid << ": ";
    for (int v : path1) cout << v << " ";
    if (path1.empty()) cout << "Khong co duong di";
    cout << endl;

    int M;
    cout << "Nhap canh toi thi con: ";
    cin >> M;
    vector<int> path2 = pathGreatThan(g, s, d, M);
    cout << "Duong di voi canh >= " << M << ": ";
    for (int v : path2) cout << v << " ";
    if (path2.empty()) cout << "Khong co duong di";
    cout << endl;

    bool connected = isConnectedMatrix(g);  // Kiểm tra liên thông cho Graph5.txt
    if (connected) {
        cout << "Do thi lien thong" << endl;
    } else {
        cout << "Do thi khong lien thong" << endl;
    }

    int comp[MAX_VERTICES] = { -1 };
    int k = connectedComponents(g, comp);
    printConnectedComponents(comp, g.numVertices, k);

    cout << "Do thi co lien thong manh? ";
    if (strongConnected(g)) {
        cout << "Co" << endl;
    } else {
        cout << "Khong" << endl;
    }

    vector<vector<int>> paths;
    allPaths(g, s, d, paths);
    cout << "Tat ca cac duong di don tu " << s << " den " << d << ":" << endl;
    for (auto p : paths) {
        for (int v : p) cout << v << " ";
        cout << endl;
    }

    return 0;
}
