#include <iostream>
#include <cmath>
using namespace std;

// Cau truc Node cho danh sach lien ket
struct Node {
	int heSo;
	int soMu;
	Node* tiep;
};

//a) Ham them mot hang tu vao dau da thuc
void chen(Node** dau, int heSo, int soMu) {
	Node* nodeMoi = new Node;
	nodeMoi->heSo = heSo;
	nodeMoi->soMu = soMu;
	nodeMoi->tiep = (*dau);
	(*dau) = nodeMoi;
}

//b) Ham in da thuc
void inDaThuc(Node* dau) {
	cout << "Da thuc la: ";
	while (dau != NULL) {
		if (dau->heSo < 0) {
			cout << "-" << abs(dau->heSo);
		} else {
			cout << "+" << dau->heSo;
		}
		cout << "x^" << dau->soMu;
		dau = dau->tiep;
	}
	cout << endl;
}

//c) Ham tinh gia tri da thuc tai x
double tinhGiaTri(Node* dau, double x) {
	double ketQua = 0;
	while (dau != NULL) {
		ketQua += dau->heSo * pow(x, dau->soMu);
		dau = dau->tiep;
	}
	return ketQua;
}

//d) Ham chen mot node vao danh sach lien ket
Node* chenTiep(Node* node, int heSo, int soMu) {
	Node* nodeMoi = new Node;
	nodeMoi->heSo = heSo;
	nodeMoi->soMu = soMu;
	nodeMoi->tiep = NULL;
	if (node) node->tiep = nodeMoi;
	return nodeMoi;
}

// Ham cong hai da thuc
Node* congDaThuc(Node* daThuc1, Node* daThuc2) {
	Node *ketQua = NULL, *cuoi = NULL;
	while (daThuc1 && daThuc2) {
		if (daThuc1->soMu > daThuc2->soMu) {
			cuoi = chenTiep(cuoi, daThuc1->heSo, daThuc1->soMu);
			daThuc1 = daThuc1->tiep;
		} else if (daThuc2->soMu > daThuc1->soMu) {
			cuoi = chenTiep(cuoi, daThuc2->heSo, daThuc2->soMu);
			daThuc2 = daThuc2->tiep;
		} else {
			int heSoMoi = daThuc1->heSo + daThuc2->heSo;
			if (heSoMoi != 0) {
				cuoi = chenTiep(cuoi, heSoMoi, daThuc1->soMu);
			}
			daThuc1 = daThuc1->tiep;
			daThuc2 = daThuc2->tiep;
		}
		if (!ketQua)
			ketQua = cuoi;
	}
	while (daThuc1) {
		cuoi = chenTiep(cuoi, daThuc1->heSo, daThuc1->soMu);
		daThuc1 = daThuc1->tiep;
	}
	while (daThuc2) {
		cuoi = chenTiep(cuoi, daThuc2->heSo, daThuc2->soMu);
		daThuc2 = daThuc2->tiep;
	}
	return ketQua;
}

//e) tinh dao ham cua da thuc
Node* daoHam(Node* daThuc) {
	Node* ketQua = NULL;
	Node* hienTai = daThuc;

	while (hienTai != NULL) {
		int heSoMoi = hienTai->heSo * hienTai->soMu;
		int soMuMoi = hienTai->soMu - 1;

		if (hienTai->soMu > 0) {
			chen(&ketQua, heSoMoi, soMuMoi);
		}

		hienTai = hienTai->tiep;
	}

	return ketQua;
}

//f) nhan hai da thuc
Node* nhanDaThuc(Node* daThuc1, Node* daThuc2) {
	Node* ketQua = NULL;

	for (Node* p1 = daThuc1; p1; p1 = p1->tiep) {
		for (Node* p2 = daThuc2; p2; p2 = p2->tiep) {
			int heSoMoi = p1->heSo * p2->heSo;
			int soMuMoi = p1->soMu + p2->soMu;

			Node* tam = ketQua;
			Node* truoc = NULL;

			while (tam && tam->soMu > soMuMoi) {
				truoc = tam;
				tam = tam->tiep;
			}

			if (tam && tam->soMu == soMuMoi) {
				tam->heSo += heSoMoi;
			} else {
				Node* nodeMoi = new Node{heSoMoi, soMuMoi, tam};
				if (truoc) {
					truoc->tiep = nodeMoi;
				} else {
					ketQua = nodeMoi;
				}
			}
		}
	}

	return ketQua;
}

//  main
int main() {
	//a) Tao da thuc 1
	Node* daThuc1 = NULL;
	chen(&daThuc1, 7, 0);
	chen(&daThuc1, 6, 3);
	chen(&daThuc1, 5, 4);

	// Tao da thuc 2
	Node* daThuc2 = NULL;
	chen(&daThuc2, 3, 1);
	chen(&daThuc2, -7, 2);
	chen(&daThuc2, 2, 3);

	//b) In hai da thuc
	inDaThuc(daThuc1);
	inDaThuc(daThuc2);

	//c) Tinh gia tri cua da thuc 1 tai x = 2
	double x = 2;
	cout << "Gia tri cua da thuc 1 tai x = " << x << " la: " << tinhGiaTri(daThuc1, x) << endl;

	//d) Cong hai da thuc
	Node* ketQuaCong = congDaThuc(daThuc1, daThuc2);
	cout << "Tong hai da thuc: ";
	inDaThuc(ketQuaCong);

	//e) Dao ham cua da thuc 
	Node* daoHamDaThuc1 = daoHam(daThuc1);
	cout << "Dao ham cua da thuc so 1: ";
	inDaThuc(daoHamDaThuc1);
	
	Node* daoHamDaThuc = daoHam(daThuc2);
	cout << "Dao ham cua da thuc so 2: ";
	inDaThuc(daoHamDaThuc);

	//f) Nhan hai da thuc
	Node* ketQuaNhan = nhanDaThuc(daThuc1, daThuc2);
	cout << "Tich cua hai da thuc: ";
	inDaThuc(ketQuaNhan);

	return 0;
}
