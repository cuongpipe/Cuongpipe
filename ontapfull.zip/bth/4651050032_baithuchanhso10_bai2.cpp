#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

#define MAX_VERTICES 100
#define INF 1000

struct Edge {
	int adjVertex;
	float weight;
};

typedef vector<vector<Edge>> Graph;

// a) Đọc đồ thị từ tệp (ma trận trọng số)
void readGraphFromFile(Graph& graph, string fileName, int& numVertices) {
	ifstream file(fileName);
	if (!file) {cout <<"khong the mo file!" << endl;
		return;
	}

	file >> numVertices;
	graph.assign(numVertices, vector<Edge>());

	for (int i = 0; i < numVertices; ++i) {
		for (int j = 0; j < numVertices; ++j) {
			float weight;
			file >> weight;
			if (weight != INF) {
				graph[i].push_back({j, weight});
			}
		}
	}

	file.close();
}

// b) In đồ thị
void printGraph(const Graph& graph) {
	for (int i = 0; i < graph.size(); ++i) {
		cout << "adjList[" << i << "]: ";
		for (const Edge& e : graph[i]) {
			cout << e.adjVertex << "(" << e.weight << ") ";
		}
		cout << endl;
	}
}

// c) BFS tìm đường đi
void PathBFS(const Graph& graph, int s, vector<int>& parent) {
	vector<bool> visited(graph.size(), false);
	parent.assign(graph.size(), -1);
	queue<int> q;
	visited[s] = true;
	parent[s] = s;
	q.push(s);
	while (!q.empty()) {
		int curr = q.front();
		q.pop();
		for (const Edge& e : graph[curr]) {
			if (!visited[e.adjVertex]) {
				visited[e.adjVertex] = true;
				parent[e.adjVertex] = curr;
				q.push(e.adjVertex);
			}
		}
	}
}

// d) In đường đi
void printPath(const vector<int>& parent, int s, int v) {
	if (parent[v] == -1) {
		cout << "khong co duong di tu" << s << " den " << v << endl;
		return;
	}
	if (v == s) {
		cout << s << " ";
		return;
	}
	printPath(parent, s, parent[v]);
	cout << v << " ";
}

// e) DFS kiểm tra liên thông
void DFS(const Graph& graph, int v, vector<bool>& visited) {
	visited[v] = true;
	for (const Edge& e : graph[v]) {
		if (!visited[e.adjVertex]) {
			DFS(graph, e.adjVertex, visited);
		}
	}
}

bool isConnected(const Graph& graph) {
	vector<bool> visited(graph.size(), false);
	DFS(graph, 0, visited);
	for (bool v : visited)
		if (!v) return false;
	return true;
}

// f/g) Thành phần liên thông
void DFSConnectedComponents(const Graph& graph, int v, vector<bool>& visited, vector<int>& component, int k) {
	visited[v] = true;
	component[v] = k;
	for (const Edge& e : graph[v]) {
		if (!visited[e.adjVertex]) {
			DFSConnectedComponents(graph, e.adjVertex, visited, component, k);
		}
	}
}

int connectedComponents(const Graph& graph, vector<int>& component) {
	int n = graph.size();
	vector<bool> visited(n, false);
	component.assign(n, -1);
	int k = 0;
	for (int i = 0; i < n; ++i) {
		if (!visited[i]) {
			++k;
			DFSConnectedComponents(graph, i, visited, component, k);
		}
	}
	return k;
}

void printConnectedComponents(const vector<int>& component, int k) {
	cout << "so luong thanh phan lien thong: " << k << endl;
	for (int i = 1; i <= k; ++i) {
		cout << "thanh phan[" << i << "]: ";
		for (int j = 0; j < component.size(); ++j) {
			if (component[j] == i)
				cout << j << " ";
		}
		cout << endl;
	}
}

// h) Kiểm tra có đường đi giữa 2 đỉnh
bool hasPath(const vector<int>& parent, int d) {
	return parent[d] != -1;
}

// i) Tìm đường đi DFS
bool pathDFSUtil(const Graph& graph, int u, int d, vector<bool>& visited, vector<int>& parent) {
	visited[u] = true;
	if (u == d) return true;
	for (const Edge& e : graph[u]) {
		if (!visited[e.adjVertex]) {
			parent[e.adjVertex] = u;
			if (pathDFSUtil(graph, e.adjVertex, d, visited, parent)) return true;
		}
	}
	return false;
}

void pathDFS(const Graph& graph, int s, int d, vector<int>& parent) {
	vector<bool> visited(graph.size(), false);
	parent.assign(graph.size(), -1);
	parent[s] = s;
	if (!pathDFSUtil(graph, s, d, visited, parent)) {
		cout << "Khong co duong di DFS từ " << s << " đến " << d << endl;
	}
}

// j) Tìm đường đi không qua đỉnh v
bool dfsAvoidVertex(const Graph& graph, int u, int d, int avoid, vector<bool>& visited, vector<int>& path) {
	if (u == avoid) return false;
	visited[u] = true;
	path.push_back(u);
	if (u == d) return true;
	for (const Edge& e : graph[u]) {
		if (!visited[e.adjVertex]) {
			if (dfsAvoidVertex(graph, e.adjVertex, d, avoid, visited, path)) return true;
		}
	}
	path.pop_back();
	return false;
}

vector<int> pathNoVertex(const Graph& graph, int s, int d, int v) {
	vector<bool> visited(graph.size(), false);
	vector<int> path;
	if (dfsAvoidVertex(graph, s, d, v, visited, path)) return path;
	return {};
}

// k) Tìm đường đi chỉ qua cạnh ≥ M
bool dfsWeightLimit(const Graph& graph, int u, int d, int M, vector<bool>& visited, vector<int>& path) {
	visited[u] = true;
	path.push_back(u);
	if (u == d) return true;
	for (const Edge& e : graph[u]) {
		if (!visited[e.adjVertex] && e.weight >= M) {
			if (dfsWeightLimit(graph, e.adjVertex, d, M, visited, path)) return true;
		}
	}
	path.pop_back();
	return false;
}

vector<int> pathGreatThan(const Graph& graph, int s, int d, int M) {
	vector<bool> visited(graph.size(), false);
	vector<int> path;
	if (dfsWeightLimit(graph, s, d, M, visited, path)) return path;
	return {};
}

// l) Kiểm tra liên thông mạnh
Graph transposeGraph(const Graph& graph) {
	int n = graph.size();
	Graph transposed(n);
	for (int u = 0; u < n; ++u) {
		for (const Edge& e : graph[u]) {
			transposed[e.adjVertex].push_back({u, e.weight});
		}
	}
	return transposed;
}

bool strongConnected(const Graph& graph) {
	int n = graph.size();
	vector<bool> visited(n, false);
	DFS(graph, 0, visited);
	for (bool v : visited)
		if (!v) return false;

	Graph transposed = transposeGraph(graph);
	fill(visited.begin(), visited.end(), false);
	DFS(transposed, 0, visited);
	for (bool v : visited)
		if (!v) return false;

	return true;
}

// m) Tìm tất cả các đường đi đơn
void allPathsUtil(const Graph& graph, int u, int d, vector<bool>& visited, vector<int>& path, vector<vector<int>>& paths) {
	visited[u] = true;
	path.push_back(u);
	if (u == d) {
		paths.push_back(path);
	} else {
		for (const Edge& e : graph[u]) {
			if (!visited[e.adjVertex])
				allPathsUtil(graph, e.adjVertex, d, visited, path, paths);
		}
	}
	path.pop_back();
	visited[u] = false;
}

void allPaths(const Graph& graph, int s, int d, vector<vector<int>>& paths) {
	vector<bool> visited(graph.size(), false);
	vector<int> path;
	allPathsUtil(graph, s, d, visited, path, paths);
}

// ===== Main Program =====
int main() {
	Graph graph;
	int numVertices;
	readGraphFromFile(graph, "Graph4.txt", numVertices);
	printGraph(graph);

	int s, d;
	cout << "nhap dinh bat dau: ";
	cin >> s;
	cout << "Nnhap dinh ket thuc: ";
	cin >> d;

	vector<int> parent;
	PathBFS(graph, s, parent);
	cout << "duong di BFS: ";
	printPath(parent, s, d);
	cout << endl;

	pathDFS(graph, s, d, parent);
	cout << "duong di DFS: ";
	printPath(parent, s, d);
	cout << endl;

	int avoid;
	cout << "nhap dinh can tranh: ";
	cin >> avoid;
	vector<int> path1 = pathNoVertex(graph, s, d, avoid);
	cout << "duong di tranh dinh " << avoid << ": ";
	for (int v : path1) cout << v << " ";
	if (path1.empty()) cout << "khong co duong di";
	cout << endl;

	int M;
	cout << "nhao trong so toi thieu: ";
	cin >> M;
	vector<int> path2 = pathGreatThan(graph, s, d, M);
	cout << "duong di trong so >= " << M << ": ";
	for (int v : path2) cout << v << " ";
	if (path2.empty()) cout << "khong có duong di";
	cout << endl;

	if (isConnected(graph)) {
		cout << "do thi lien thong "<< endl;
	} else {
		cout << "do thi khong lien thong" << endl;
	}

	vector<int> comp;
	int k = connectedComponents(graph, comp);
	printConnectedComponents(comp, k);

	// Kiểm tra đồ thị có liên thông mạnh hay không
	cout << "do thi lien thong manh?" << endl;
	bool isStronglyConnected = strongConnected(graph); // Kiểm tra liên thông mạnh
	if (isStronglyConnected) {
		cout << " Co" << endl;
	} else {
		cout << "Khong" << endl;
	}


	vector<vector<int>> all;
	allPaths(graph, s, d, all);
	cout << "tat ca duong di tu " << s << " den " << d << ":" << endl;
	for (auto& p : all) {
		for (int v : p) cout << v << " ";
		cout << endl;
	}

	return 0;
}
