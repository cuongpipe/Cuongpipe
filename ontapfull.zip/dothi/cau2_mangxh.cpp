#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

#define MAX 100

// a) Khai báo danh sách kề
struct Graph {
    int numUsers;
    vector<int> adj[MAX]; // adj[u] là danh sách người u theo dõi
};

// Đọc đồ thị từ file
void readGraphFromFile(Graph& g, string filename) {
    ifstream file(filename);
    if (!file) {
        cout << "Khong the mo file!" << endl;
        return;
    }
    int n, m;
    file >> g.numUsers >> m;
    for (int i = 0; i < m; i++) {
        int u, v;
        file >> u >> v;
        g.adj[u].push_back(v); // u theo dõi v
    }
    file.close();
}

// b) Người x có nhận được bài từ người y không?
bool canReceivePost(Graph g, int x, int y) {
    bool visited[MAX] = {false};
    queue<int> q;
    visited[y] = true;
    q.push(y); // bài được phát tán từ y
    while (!q.empty()) {
        int u = q.front(); q.pop();
        if (u == x) return true;
        for (int v : g.adj[u]) {
            if (!visited[v]) {
                visited[v] = true;
                q.push(v);
            }
        }
    }
    return false;
}

// c) Số người theo dõi người x
int countFollowers(Graph g, int x) {
    int count = 0;
    for (int i = 0; i < g.numUsers; i++) {
        for (int v : g.adj[i]) {
            if (v == x) count++;
        }
    }
    return count;
}

// d) Hai người x và y có nhận được bài của nhau không?
bool mutualReceive(Graph g, int x, int y) {
    return canReceivePost(g, x, y) && canReceivePost(g, y, x);
}

// e) Chương trình chính
int main() {
    Graph g;
    readGraphFromFile(g, "dothi.txt");

    cout << "So nguoi trong mang: " << g.numUsers << endl;

    // 1. Người 1 có bao nhiêu người theo dõi
    cout << "So nguoi theo doi nguoi 1: " << countFollowers(g, 1) << endl;

    // 2. Người 4 có nhận được bài từ người 0 không?
    if (canReceivePost(g, 4, 0)) {
        cout << "Nguoi 4 co nhan duoc bai viet tu nguoi 0" << endl;
    } else {
        cout << "Nguoi 4 KHONG nhan duoc bai viet tu nguoi 0" << endl;
    }

    // 3. Người 0 và 4 có nhận được bài của nhau không?
    if (mutualReceive(g, 0, 4)) {
        cout << "Nguoi 0 va 4 co nhan duoc bai cua nhau" << endl;
    } else {
        cout << "Nguoi 0 va 4 KHONG nhan duoc bai cua nhau" << endl;
    }

    return 0;
}
