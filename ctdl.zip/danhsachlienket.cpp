#include<iostream>
struct Node{
	int data;
	struct Node * next;
};
typedef Node * Node;
int main(){
	
	
	
	return 0;
	
}