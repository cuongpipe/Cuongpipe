#include <iostream>
using namespace std;

// ======================= STACK (NGĂN XẾP) =======================
class Stack {
private:
    struct Node {
        int data;
        Node* next;
    };
    Node* top; // Con trỏ tới phần tử đầu tiên

public:
    Stack() : top(nullptr) {}

    void push(int value) {
        Node* newNode = new Node{value, top};
        top = newNode;
    }

    int pop() {
        if (isEmpty()) {
            cout << "Stack rong!" << endl;
            return -1;
        }
        int value = top->data;
        Node* temp = top;
        top = top->next;
        delete temp;
        return value;
    }

    bool isEmpty() {
        return top == nullptr;
    }

    int peek() {
        if (isEmpty()) {
            cout << "Stack rong!" << endl;
            return -1;
        }
        return top->data;
    }

    void print() {
        Node* temp = top;
        while (temp) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

// ======================= QUEUE (HÀNG ĐỢI) =======================
class Queue {
private:
    struct Node {
        int data;
        Node* next;
    };
    Node *front, *rear;

public:
    Queue() : front(nullptr), rear(nullptr) {}

    void enqueue(int value) {
        Node* newNode = new Node{value, nullptr};
        if (rear == nullptr) {
            front = rear = newNode;
            return;
        }
        rear->next = newNode;
        rear = newNode;
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Queue rong!" << endl;
            return -1;
        }
        int value = front->data;
        Node* temp = front;
        front = front->next;
        if (front == nullptr) rear = nullptr;
        delete temp;
        return value;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    int peek() {
        if (isEmpty()) {
            cout << "Queue rong!" << endl;
            return -1;
        }
        return front->data;
    }

    void print() {
        Node* temp = front;
        while (temp) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

// ======================= TEST CODE =======================
int main() {
    // Stack
    Stack stack;
    stack.push(10);
    stack.push(20);
    stack.push(30);
    cout << "Stack sau khi push: ";
    stack.print();
    cout << "Pop stack: " << stack.pop() << endl;
    cout << "Stack sau khi pop: ";
    stack.print();

    // Queue
    Queue queue;
    queue.enqueue(1);
    queue.enqueue(2);
    queue.enqueue(3);
    cout << "Queue sau khi enqueue: ";
    queue.print();
    cout << "Dequeue queue: " << queue.dequeue() << endl;
    cout << "Queue sau khi dequeue: ";
    queue.print();

    return 0;
}
