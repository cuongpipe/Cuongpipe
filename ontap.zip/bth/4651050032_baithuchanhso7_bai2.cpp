#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

using namespace std;

struct EngDict {
    EngDict* child[27];
    EngDict() {
        fill(begin(child), end(child), nullptr);
    }
};

EngDict* initDict() {
    return new EngDict();
}

void insertWord(EngDict* root, const string& word) {
    EngDict* p = root;
    for (char c : word) {
        int index = tolower(c) - 'a';
        if (index < 0 || index >= 26) continue; // Bo qua ky tu khong phai chu cai
        if (!p->child[index]) p->child[index] = new EngDict();
        p = p->child[index];
    }
    p->child[26] = new EngDict(); // Danh dau ket thuc tu
}

int readDictFromFile(const string& fileName, EngDict* root) {
    ifstream file(fileName);
    string word;
    int count = 0;
    while (getline(file, word)) {
        insertWord(root, word);
        count++;
    }
    return count;
}

bool find(EngDict* root, const string& word) {
    EngDict* p = root;
    for (char c : word) {
        int index = tolower(c) - 'a';
        if (index < 0 || index >= 26) continue;
        if (!p->child[index]) return false;
        p = p->child[index];
    }
    return p->child[26] != nullptr;
}

int treeHeight(EngDict* root) {
    if (!root) return 0;
    int maxHeight = 0;
    for (int i = 0; i < 27; ++i) {
        if (root->child[i]) {
            maxHeight = max(maxHeight, treeHeight(root->child[i]));
        }
    }
    return 1 + maxHeight;
}

int countWords(EngDict* root) {
    if (!root) return 0;
    int count = 0;
    if (root->child[26]) count++;
    for (int i = 0; i < 26; ++i) {
        count += countWords(root->child[i]);
    }
    return count;
}

int minNonLeafChildren(EngDict* root) {
    if (!root || root->child[26]) return 27;
    int numChildren = 0;
    for (int i = 0; i < 26; ++i) {
        if (root->child[i]) numChildren++;
    }
    int minChildren = numChildren;
    for (int i = 0; i < 26; ++i) {
        if (root->child[i]) {
            minChildren = min(minChildren, minNonLeafChildren(root->child[i]));
        }
    }
    return minChildren;
}

void findWordsWithPrefix(EngDict* root, const string& prefix, string current, vector<string>& results) {
    if (root->child[26]) results.push_back(prefix + current);
    for (int i = 0; i < 26; ++i) {
        if (root->child[i]) {
            findWordsWithPrefix(root->child[i], prefix, current + (char)('a' + i), results);
        }
    }
}

void findLongestWords(EngDict* root, string current, vector<string>& longestWords, int& maxLength) {
    if (root->child[26]) {
        if (current.size() > maxLength) {
            maxLength = current.size();
            longestWords.clear();
            longestWords.push_back(current);
        } else if (current.size() == maxLength) {
            longestWords.push_back(current);
        }
    }
    for (int i = 0; i < 26; ++i) {
        if (root->child[i]) {
            findLongestWords(root->child[i], current + (char)('a' + i), longestWords, maxLength);
        }
    }
}

int main() {
    EngDict* root = initDict();
    int wordCount = readDictFromFile("words_alpha.txt", root);
    cout << wordCount << " words" << endl;

    // Nhap tu de kiem tra
    string input;
    cout << "Nhap mot tu de kiem tra: ";
    cin >> input;
    if (find(root, input))
        cout << "Tu '" << input << "' co trong tu dien." << endl;
    else
        cout << "Tu '" << input << "' khong co trong tu dien." << endl;

    // Chieu cao cay
    int height = treeHeight(root);
    cout << "Chieu cao cua cay tu dien: " << height << endl;

    // So tu trong cay
    int totalWords = countWords(root);
    cout << "Tong so tu: " << totalWords << endl;

    // So nut con it nhat (tru nut la)
    int minChildren = minNonLeafChildren(root);
    cout << "So nut con it nhat (tru nut la): " << minChildren << endl;

    // Liet ke tu bat dau bang xau s
    string prefix;
    cout << "Nhap tien to can tim: ";
    cin >> prefix;
    EngDict* p = root;
    bool exists = true;
    for (char c : prefix) {
        int index = tolower(c) - 'a';
        if (index < 0 || index >= 26) continue;
        if (p->child[index]) p = p->child[index];
        else {
            exists = false;
            break;
        }
    }
    if (exists) {
        vector<string> prefixWords;
        findWordsWithPrefix(p, prefix, "", prefixWords);
        cout << "Cac tu bat dau bang " << prefix << ":" << endl;
        for (const string& word : prefixWords)
            cout << word << endl;
    } else {
        cout << "Khong co tu nao bat dau bang tien to nay." << endl;
    }

    // Tu dai nhat
    vector<string> longestWords;
    int maxLength = 0;
    findLongestWords(root, "", longestWords, maxLength);
    cout << "Cac tu dai nhat " << maxLength << " chu cai: "<< endl;
    for (const string& word : longestWords)
        cout << word << endl;

    return 0;
}
