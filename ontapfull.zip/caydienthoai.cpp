#include <iostream>
#include <string>
using namespace std;

struct ThueBao {
    string name;
    string soDienThoai; // số điện thoại, cũng là khóa
};

struct Node {
    ThueBao data;
    Node* left;
    Node* right;
};

Node* createNode(ThueBao tb) {
    Node* root = new Node;
    root->data = tb;
    root->left = root->right = nullptr;
    return root;
}

void them(Node*& root, ThueBao tb) {
    if (root == nullptr) {
        root = createNode(tb);
    } 
	else if (tb.soDienThoai < root->data.soDienThoai) {
        them(root->left, tb);
    } 
	else if (tb.soDienThoai > root->data.soDienThoai) {
        them(root->right, tb);
    } 
	else {
        cout << "So dien thoai da ton tai: " << tb.soDienThoai << endl;
    }
}




// Liệt kê các số bắt đầu bằng tiền tố x
void lietKeTheoDau(Node* root, const string& x) {
    if (!root) return;
    if (root->data.soDienThoai.substr(0, x.size()) == x)
        cout << "  "<< root->data.name << ": " << root->data.soDienThoai << endl;
    lietKeTheoDau(root->left, x);
    lietKeTheoDau(root->right, x);
}
// liệt kê các số kết thúc bằng tiền tố x
void lietKeTheocuoi(Node* root, const string x) {
    if (!root) return;

    const string soDienThoai = root->data.soDienThoai;
    if (soDienThoai.size() >= x.size() && soDienThoai.substr(soDienThoai.size() - x.size()) == x)
        cout << "  " << root->data.name << ": " << soDienThoai << endl;

    lietKeTheocuoi(root->left, x);
    lietKeTheocuoi(root->right, x);
}


// Tìm thuê bao theo số điện thoại
bool timKiem(Node* root, const string& soDienThoai) {
    if (!root) return false;
    if (root->data.soDienThoai == soDienThoai) return true;
    if (soDienThoai < root->data.soDienThoai)
        return timKiem(root->left, soDienThoai);
    else
        return timKiem(root->right, soDienThoai);
}

// Tìm node nhỏ nhất trong cây (dùng để thay thế khi xóa)
Node* timMin(Node* root) {
    while (root && root->left)
        root = root->left;
    return root;
}

// Xóa thuê bao theo số điện thoại
Node* xoaNode(Node* root, const string& soDienThoai) {
    if (!root) return nullptr;

    if (soDienThoai < root->data.soDienThoai)
        root->left = xoaNode(root->left, soDienThoai);
    else if (soDienThoai > root->data.soDienThoai)
        root->right = xoaNode(root->right, soDienThoai);
    else {
        // tìm được node cần xóa
        if (!root->left) {
            Node* tmp = root->right;
            delete root;
            return tmp;
        } else if (!root->right) {
            Node* tmp = root->left;
            delete root;
            return tmp;
        } else {
            Node* minNode = timMin(root->right);
            root->data = minNode->data;
            root->right = xoaNode(root->right, minNode->data.soDienThoai);
        }
    }
    return root;
}

// In cây dạng trung thứ (in-order)
void inOrder(Node* root) {
    if (!root) return;
    inOrder(root->left);
    cout << root->data.name << ": " << root->data.soDienThoai << endl;
    inOrder(root->right);
}



// in cay can phai
void inCay(Node* root, int space = 0) {
    if (root == nullptr) return;

    // In node hiện tại trước
    cout << string(space, ' ') << root->data.name << " (" << root->data.soDienThoai << ")" << endl;

    // In nhánh phải trước
    inCay(root->right, space + 4);

    // Sau đó in nhánh trái
    inCay(root->left, space + 4);
}

// In kiểu: phải -> node -> trái
void printTree(Node* root, int space = 0) {
    if (root == nullptr) return;

    const int INDENT = 5;
    printTree(root->right, space + INDENT);
    cout << string(space, ' ') << root->data.name << " (" << root->data.soDienThoai << ")" << endl;
    printTree(root->left, space + INDENT);
}


int main() {
    Node* root = nullptr;

    // + Tạo cây theo hình vẽ đơn giản (3 level)
    them(root, {"An", "0938"});
    them(root, {"Binh", "0912"});
    them(root, {"Cuong", "0989"});
    them(root, {"Hoa", "0989123456"});
    them(root, {"Dung", "0989456123"});

    // + Thêm 5 thuê bao điện thoại khác
    them(root, {"Hanh", "0965123456"});
    them(root, {"Tuan", "0909123456"});
    them(root, {"Linh", "0989555666"});
    them(root, {"Minh", "0944123456"});
    them(root, {"Phat", "0912333444"});

    cout << "\n Danh sach thue bao (in-order):\n";
    inCay( root);

    cout << "\n Danh sach cac so bat dau bang '0989':\n";
    lietKeTheoDau(root, "0989");
    
    cout << "\n Danh sach cac so cuoi bang '5666':\n";
    lietKeTheocuoi(root, "4");	

    cout << "\n Kiem tra so 0912345678 co trong cay: ";
    cout << (timKiem(root, "0912345678") ? "Co" : "Khong") << endl;

    string sdt_canxoa = "0978123456";
	cout << "\nXoa so 0978123456\n";
    root = xoaNode(root, sdt_canxoa);

    cout << "\n Danh sach thue bao sau khi xoa sdt " << sdt_canxoa << ":"<< endl;
    inCay( root);
  
  	cout << "in cai cay" << endl;
   	inCay( root);
   
   	cout << "in cai cay 2" << endl;
   	printTree(root);
    return 0;
}
