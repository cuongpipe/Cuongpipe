﻿namespace qlbay
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grid_datve = new System.Windows.Forms.DataGridView();
            this.thôngTinKháchĐặtVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinĐặtVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_loc = new System.Windows.Forms.ComboBox();
            this.btn_them = new System.Windows.Forms.Button();
            this.dtp_tgdat = new System.Windows.Forms.DateTimePicker();
            this.label_tgdat = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_giatien = new System.Windows.Forms.TextBox();
            this.txt_machuyen = new System.Windows.Forms.TextBox();
            this.txt_idkhach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_tongsotiendat = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid_datve)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grid_datve
            // 
            this.grid_datve.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_datve.Location = new System.Drawing.Point(36, 47);
            this.grid_datve.Name = "grid_datve";
            this.grid_datve.Size = new System.Drawing.Size(477, 248);
            this.grid_datve.TabIndex = 0;
            // 
            // thôngTinKháchĐặtVéToolStripMenuItem
            // 
            this.thôngTinKháchĐặtVéToolStripMenuItem.Name = "thôngTinKháchĐặtVéToolStripMenuItem";
            this.thôngTinKháchĐặtVéToolStripMenuItem.Size = new System.Drawing.Size(141, 20);
            this.thôngTinKháchĐặtVéToolStripMenuItem.Text = "Thông tin khách đặt vé";
            this.thôngTinKháchĐặtVéToolStripMenuItem.Click += new System.EventHandler(this.thôngTinKháchĐặtVéToolStripMenuItem_Click);
            // 
            // thôngTinĐặtVéToolStripMenuItem
            // 
            this.thôngTinĐặtVéToolStripMenuItem.Name = "thôngTinĐặtVéToolStripMenuItem";
            this.thôngTinĐặtVéToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.thôngTinĐặtVéToolStripMenuItem.Text = "Thông tin đặt vé";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinKháchĐặtVéToolStripMenuItem,
            this.thôngTinĐặtVéToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(919, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(576, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 33;
            this.label6.Text = "chọn khách hàng";
            // 
            // cb_loc
            // 
            this.cb_loc.FormattingEnabled = true;
            this.cb_loc.Location = new System.Drawing.Point(673, 61);
            this.cb_loc.Name = "cb_loc";
            this.cb_loc.Size = new System.Drawing.Size(121, 21);
            this.cb_loc.TabIndex = 32;
            this.cb_loc.SelectedIndexChanged += new System.EventHandler(this.cb_loc_SelectedIndexChanged);
            // 
            // btn_them
            // 
            this.btn_them.Location = new System.Drawing.Point(582, 272);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(317, 23);
            this.btn_them.TabIndex = 29;
            this.btn_them.Text = "thêm";
            this.btn_them.UseVisualStyleBackColor = true;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // dtp_tgdat
            // 
            this.dtp_tgdat.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_tgdat.Location = new System.Drawing.Point(673, 202);
            this.dtp_tgdat.Name = "dtp_tgdat";
            this.dtp_tgdat.Size = new System.Drawing.Size(223, 20);
            this.dtp_tgdat.TabIndex = 28;
            // 
            // label_tgdat
            // 
            this.label_tgdat.AutoSize = true;
            this.label_tgdat.Location = new System.Drawing.Point(576, 208);
            this.label_tgdat.Name = "label_tgdat";
            this.label_tgdat.Size = new System.Drawing.Size(66, 13);
            this.label_tgdat.TabIndex = 26;
            this.label_tgdat.Text = "thời gian đặt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(576, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "id khách";
            // 
            // txt_giatien
            // 
            this.txt_giatien.Location = new System.Drawing.Point(673, 163);
            this.txt_giatien.Name = "txt_giatien";
            this.txt_giatien.Size = new System.Drawing.Size(223, 20);
            this.txt_giatien.TabIndex = 24;
            // 
            // txt_machuyen
            // 
            this.txt_machuyen.Location = new System.Drawing.Point(673, 128);
            this.txt_machuyen.Name = "txt_machuyen";
            this.txt_machuyen.Size = new System.Drawing.Size(223, 20);
            this.txt_machuyen.TabIndex = 23;
            // 
            // txt_idkhach
            // 
            this.txt_idkhach.Location = new System.Drawing.Point(673, 92);
            this.txt_idkhach.Name = "txt_idkhach";
            this.txt_idkhach.Size = new System.Drawing.Size(223, 20);
            this.txt_idkhach.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(576, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "mã chuyến";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(579, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 35;
            this.label3.Text = "giá tiền";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(579, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "tổng số tiền  đặt vé là:";
            // 
            // label_tongsotiendat
            // 
            this.label_tongsotiendat.AutoSize = true;
            this.label_tongsotiendat.Location = new System.Drawing.Point(698, 239);
            this.label_tongsotiendat.Name = "label_tongsotiendat";
            this.label_tongsotiendat.Size = new System.Drawing.Size(39, 13);
            this.label_tongsotiendat.TabIndex = 37;
            this.label_tongsotiendat.Text = "0 VND";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 450);
            this.Controls.Add(this.label_tongsotiendat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cb_loc);
            this.Controls.Add(this.btn_them);
            this.Controls.Add(this.dtp_tgdat);
            this.Controls.Add(this.label_tgdat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_giatien);
            this.Controls.Add(this.txt_machuyen);
            this.Controls.Add(this.txt_idkhach);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.grid_datve);
            this.HelpButton = true;
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.grid_datve)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView grid_datve;
        private System.Windows.Forms.ToolStripMenuItem thôngTinKháchĐặtVéToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinĐặtVéToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cb_loc;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.DateTimePicker dtp_tgdat;
        private System.Windows.Forms.Label label_tgdat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_giatien;
        private System.Windows.Forms.TextBox txt_machuyen;
        private System.Windows.Forms.TextBox txt_idkhach;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_tongsotiendat;
    }
}