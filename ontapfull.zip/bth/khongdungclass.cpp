#include <iostream>
using namespace std;

// Node cho danh sách liên kết
struct Node {
    int data;
    Node* next;
};

// ======================= STACK (NGĂN XẾP) =======================
// Hàm push (thêm phần tử vào đầu stack)
void push(Node*& top, int value) {
    Node* newNode = new Node{value, top};
    top = newNode;
}

// Hàm pop (xóa phần tử đầu stack)
int pop(Node*& top) {
    if (top == nullptr) {
        cout << "Stack rong!" << endl;
        return -1;
    }
    int value = top->data;
    Node* temp = top;
    top = top->next;
    delete temp;
    return value;
}

// Hàm kiểm tra stack có rỗng không
bool isEmptyStack(Node* top) {
    return top == nullptr;
}

// Hàm lấy phần tử đầu mà không xóa (peek)
int peekStack(Node* top) {
    if (top == nullptr) {
        cout << "Stack rong!" << endl;
        return -1;
    }
    return top->data;
}

// Hàm in stack
void printStack(Node* top) {
    while (top) {
        cout << top->data << " ";
        top = top->next;
    }
    cout << endl;
}

// ======================= QUEUE (HÀNG ĐỢI) =======================
// Hàm enqueue (thêm phần tử vào cuối queue)
void enqueue(Node*& front, Node*& rear, int value) {
    Node* newNode = new Node{value, nullptr};
    if (rear == nullptr) {
        front = rear = newNode;
        return;
    }
    rear->next = newNode;
    rear = newNode;
}

// Hàm dequeue (xóa phần tử đầu queue)
int dequeue(Node*& front, Node*& rear) {
    if (front == nullptr) {
        cout << "Queue rong!" << endl;
        return -1;
    }
    int value = front->data;
    Node* temp = front;
    front = front->next;
    if (front == nullptr) rear = nullptr; // Nếu queue trống thì rear cũng phải null
    delete temp;
    return value;
}

// Hàm kiểm tra queue có rỗng không
bool isEmptyQueue(Node* front) {
    return front == nullptr;
}

// Hàm lấy phần tử đầu mà không xóa (peek)
int peekQueue(Node* front) {
    if (front == nullptr) {
        cout << "Queue rong!" << endl;
        return -1;
    }
    return front->data;
}

// Hàm in queue
void printQueue(Node* front) {
    while (front) {
        cout << front->data << " ";
        front = front->next;
    }
    cout << endl;
}

// ======================= TEST CODE =======================
int main() {
    // Stack
    Node* stackTop = nullptr;
    push(stackTop, 10);
    push(stackTop, 20);
    push(stackTop, 30);
    cout << "Stack sau khi push: ";
    printStack(stackTop);
    cout << "Pop stack: " << pop(stackTop) << endl;
    cout << "Stack sau khi pop: ";
    printStack(stackTop);
    
    // Queue
    Node* queueFront = nullptr;
    Node* queueRear = nullptr;
    enqueue(queueFront, queueRear, 1);
    enqueue(queueFront, queueRear, 2);
    enqueue(queueFront, queueRear, 3);
    cout << "Queue sau khi enqueue: ";
    printQueue(queueFront);
    cout << "Dequeue queue: " << dequeue(queueFront, queueRear) << endl;
    cout << "Queue sau khi dequeue: ";
    printQueue(queueFront);

    return 0;
}
