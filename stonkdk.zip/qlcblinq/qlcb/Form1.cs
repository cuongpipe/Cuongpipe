﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Data.Linq.Mapping;


namespace qlcb
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
            txt_pass.PasswordChar = '*';
        }

        //phân linq (DƯỚI)
        [Table(Name = "TaiKhoan")]
        
        public class TaiKhoan
        {
            [Column(IsPrimaryKey = true)]
            public string tendangnhap { get; set; }

            [Column]
            public string matkhau { get; set; }
        }


        //datacontext SqlConnection + SqlCommand kết hợp lại
        public class QLCBDataContext : DataContext
        {
            public QLCBDataContext(string connection) : base(connection) { }
            public Table<TaiKhoan> TaiKhoans;

        }
        //phần linq (TRÊN)

        private void btn_login_Click(object sender, EventArgs e)
        {
            string connStr = @"Data Source=XR;Initial Catalog=qlcb;Integrated Security=True";

            try
            {
                QLCBDataContext db = new QLCBDataContext(connStr);

                //truy vấn xem có tải khoản trong database . if k có trả về null else có thì trả về khác null
                var users = (from tk in db.TaiKhoans
                            where tk.tendangnhap.Trim() == txt_user.Text.Trim()
                               && tk.matkhau.Trim() == txt_pass.Text.Trim()
                            select tk);
                        //chú thích: from tk in db.TaiKhoans == from TaiKhoans(lệnh sql bình thường) MÀ TaiKhoans từ public class QLCBDataContext
                                     //select tk (tức là SELECT * (lệnh sql bình thường)) 

                // lấy dòng đầu tiên từ kết quả truy vấn
                var user = users.FirstOrDefault();

                if (user != null)
                {
                    MessageBox.Show("Đăng nhập thành công!");  
                    Form2 form2 = new Form2();
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập/Mật khẩu không hợp lệ!");
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi kết nối CSDL!");
            }
        }


    }
}
