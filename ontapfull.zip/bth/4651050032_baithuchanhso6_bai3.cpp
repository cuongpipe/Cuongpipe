#include<iostream>
using namespace std;
// Cấu trúc node cho cây nhị phân tìm kiếm
struct Node {
	int key;
	Node* left;
	Node* right;

	Node(int x) {
		key = x;
		left = NULL;
		right = NULL;
	}
};


// Hàm chèn phần tử vào cây tìm kiếm nhị phân
Node* insert(Node* root, int x) {
	if (!root) return new Node(x);
	if (x < root->key)
		root->left = insert(root->left, x);
	else if (x > root->key)
		root->right = insert(root->right, x);
	// nếu bằng thì không chèn vì tập hợp không có phần tử trùng
	return root;
}
//a) viet ham in(int x, Node *s): kiem tra x thuoc tap S khong. dung thuat toan tim x trong cay tim kiem nhi phan co nut goc la S
bool in(int x, Node *S) {
	if (!S)
		return false;
	else if (S->key == x)
		return true;
	else if (S->key > x)
		return in(x, S->left);
	else
		return in(x, S->right);
}
//b) viet ham print(Node *s): in cac so trong tap hop S. su dung duyet cay nhi phan
void print(Node *S) {
	if (S) {
		print(S->left);
		cout << S->key << " ";
		print(S->right);
	}
//	cout << endl;
}
//c) kiem tra tap con
//Check a set of integers is subset a other set
bool subset(Node* S1, Node* S2) {
	if (!S1)
		return true;
	else
		return subset(S1->left, S2) && subset(S1->right, S2) && in(S1->key, S2);
}

//d) giao 2 tap hop
//intersection of two sets
Node* intersectionSet(Node* S1, Node* S2, Node* S3) {
	if (S1) {
		if (in(S1->key, S2))
			S3 = insert(S3, S1->key);
		S3 = intersectionSet(S1->left, S2, S3);
		S3 = intersectionSet(S1->right, S2, S3);
	}
	return S3;
}


//e)hop 2 tap hop
//Append a set into another set
Node* append(Node* S1, Node* S2) {
	if (S1) {
		S2 = insert(S2, S1->key);
		S2 = append(S1->left, S2);
		S2 = append(S1->right, S2);
	}
	return S2;
}
//Union of two sets
Node* unionSet(Node* S1, Node*S2) {
	Node* S3 = NULL;
	S3 = append(S1, S3);
	S3 = append(S2, S3);
	return S3;
}
// i) Hiệu hai tập hợp
Node* differenceSet(Node* S1, Node* S2, Node* S3) {
	if (S1) {
		if (!in(S1->key, S2))
			S3 = insert(S3, S1->key);
		S3 = differenceSet(S1->left, S2, S3);
		S3 = differenceSet(S1->right, S2, S3);
	}
	return S3;
}

// j) Chuyển mảng -> cây tập hợp
Node* arrToSet(int arr[], int n) {
	Node* S = NULL;
	for (int i = 0; i < n; i++) {
		S = insert(S, arr[i]);
	}
	return S;
}
// k) Chuyển tập hợp -> mảng, theo thứ tự tăng
int setToArr(Node* S, int arr[], int index = 0) {
	if (!S) return index;
	index = setToArr(S->left, arr, index);
	arr[index++] = S->key;
	index = setToArr(S->right, arr, index);
	return index;
}



//Hàm main():
int main() {
	Node *S1 = NULL, *S2 = NULL, *S3 = NULL;
	int i, n = 100;
//Insert to S1
	for(i = 1; i <= n; i++) {
		S1 = insert(S1, i);
	}
	cout << "S1: ";
	print(S1);
	cout << endl;
//Insert to S2
	for(i = n/2; i <= 2*n; i++) {
		S2 = insert(S2, i);
	}
	cout << "S2: ";
	print(S2);
	cout << endl;
	bool b = subset(S1, S2);
	if (b)
		cout << "S1 la tap hop con cua S2" << endl;
	else
		cout << "S1 ikhong la tap con cua S2" << endl;
	// Union
	Node* S4 = unionSet(S1, S2);
	cout << "hop S1 hop S2: ";
	print(S4);
	cout << endl;
	
	S3 = intersectionSet(S1, S2, S3);
	cout << "S3: ";
	print(S3);
	cout << endl;

	// hieu
	Node* S5 = NULL;
	S5 = differenceSet(S1, S2, S5);
	cout << "hieu S1 - S2: ";
	print(S5);
	cout << endl;

	int arr[] = {5, 10, 15, 20, 10, 5}; 
	Node* S6 = arrToSet(arr, 6);
	cout << "tap hop tu mang: ";
	print(S6);

	int arrOut[1000], len;
	len = setToArr(S6, arrOut);
	cout << "mang tu tap hop: ";
	for (int i = 0; i < len; i++) {
		cout << arrOut[i] << " ";
	}
	cout << endl;

	return 0;
}
