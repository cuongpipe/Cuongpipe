#include <iostream>
#include <cmath>
using namespace std;

// Cau truc Node cho danh sach lien ket
struct Node {
    int heSo; // Hệ số của hạng tử
    int soMu; // Số mũ của hạng tử
    Node* tiep; // Con trỏ trỏ đến phần tử tiếp theo
};

// a) Hàm thêm một hạng tử vào đầu đa thức
void chen(Node** dau, int heSo, int soMu) {
    Node* nodeMoi = new Node; // Tạo một node mới
    nodeMoi->heSo = heSo; // Gán hệ số
    nodeMoi->soMu = soMu; // Gán số mũ
    nodeMoi->tiep = (*dau); // Trỏ node mới tới node đầu danh sách
    (*dau) = nodeMoi; // Cập nhật lại node đầu
}

// b) Hàm in đa thức
void inDaThuc(Node* dau) {
    cout << "Da thuc la: "; // In tiêu đề
    while (dau != NULL) { // Lặp qua từng phần tử
        if (dau->heSo < 0) { // Kiểm tra dấu âm
            cout << "-" << abs(dau->heSo); // In hệ số dương kèm dấu -
        } else {
            cout << "+" << dau->heSo; // In hệ số có dấu +
        }
        cout << "x^" << dau->soMu; // In biến x và số mũ
        dau = dau->tiep; // Di chuyển đến phần tử tiếp theo
    }
    cout << endl;
}

// c) Hàm tính giá trị đa thức tại x
double tinhGiaTri(Node* dau, double x) {
    double ketQua = 0; // Khởi tạo kết quả
    while (dau != NULL) { // Duyệt từng phần tử
        ketQua += dau->heSo * pow(x, dau->soMu); // Tính giá trị từng hạng tử và cộng vào kết quả
        dau = dau->tiep; // Di chuyển đến phần tử tiếp theo
    }
    return ketQua; // Trả về kết quả
}

// d) Hàm chèn một node vào danh sách liên kết
Node* chenTiep(Node* node, int heSo, int soMu) {
    Node* nodeMoi = new Node; // Tạo node mới
    nodeMoi->heSo = heSo; // Gán hệ số
    nodeMoi->soMu = soMu; // Gán số mũ
    nodeMoi->tiep = NULL; // Node mới là phần tử cuối
    if (node) node->tiep = nodeMoi; // Nếu danh sách có sẵn, nối node mới vào
    return nodeMoi; // Trả về node mới
}

// Hàm cộng hai đa thức
Node* congDaThuc(Node* daThuc1, Node* daThuc2) {
    Node *ketQua = NULL, *cuoi = NULL; // Khởi tạo kết quả và con trỏ cuối
    while (daThuc1 && daThuc2) { // Duyệt hai danh sách cùng lúc
        if (daThuc1->soMu > daThuc2->soMu) { // Nếu số mũ của đa thức 1 lớn hơn
            cuoi = chenTiep(cuoi, daThuc1->heSo, daThuc1->soMu);
            daThuc1 = daThuc1->tiep;
        } else if (daThuc2->soMu > daThuc1->soMu) { // Nếu số mũ của đa thức 2 lớn hơn
            cuoi = chenTiep(cuoi, daThuc2->heSo, daThuc2->soMu);
            daThuc2 = daThuc2->tiep;
        } else { // Nếu số mũ bằng nhau
            int heSoMoi = daThuc1->heSo + daThuc2->heSo;
            if (heSoMoi != 0) {
                cuoi = chenTiep(cuoi, heSoMoi, daThuc1->soMu);
            }
            daThuc1 = daThuc1->tiep;
            daThuc2 = daThuc2->tiep;
        }
        if (!ketQua)
            ketQua = cuoi; // Cập nhật con trỏ đầu tiên
    }
    while (daThuc1) { // Thêm phần tử còn lại của daThuc1
        cuoi = chenTiep(cuoi, daThuc1->heSo, daThuc1->soMu);
        daThuc1 = daThuc1->tiep;
    }
    while (daThuc2) { // Thêm phần tử còn lại của daThuc2
        cuoi = chenTiep(cuoi, daThuc2->heSo, daThuc2->soMu);
        daThuc2 = daThuc2->tiep;
    }
    return ketQua; // Trả về kết quả
}

// e) Hàm tính đạo hàm của đa thức
Node* daoHam(Node* daThuc) {
    Node* ketQua = NULL; // Khởi tạo kết quả
    Node* hienTai = daThuc; // Con trỏ duyệt danh sách
    while (hienTai != NULL) {
        int heSoMoi = hienTai->heSo * hienTai->soMu; // Tính hệ số mới
        int soMuMoi = hienTai->soMu - 1; // Giảm bậc
        if (hienTai->soMu > 0) {
            chen(&ketQua, heSoMoi, soMuMoi);
        }
        hienTai = hienTai->tiep;
    }
    return ketQua; // Trả về kết quả
}

// f) Hàm nhân hai đa thức
Node* nhanDaThuc(Node* daThuc1, Node* daThuc2) {
    Node* ketQua = NULL;
    for (Node* p1 = daThuc1; p1; p1 = p1->tiep) {
        for (Node* p2 = daThuc2; p2; p2 = p2->tiep) {
            int heSoMoi = p1->heSo * p2->heSo;
            int soMuMoi = p1->soMu + p2->soMu;
            Node* tam = ketQua;
            Node* truoc = NULL;
            while (tam && tam->soMu > soMuMoi) {
                truoc = tam;
                tam = tam->tiep;
            }
            if (tam && tam->soMu == soMuMoi) {
                tam->heSo += heSoMoi;
            } else {
                Node* nodeMoi = new Node{heSoMoi, soMuMoi, tam};
                if (truoc) {
                    truoc->tiep = nodeMoi;
                } else {
                    ketQua = nodeMoi;
                }
            }
        }
    }
    return ketQua;
}

// main
int main() {
    Node* daThuc1 = NULL;
    chen(&daThuc1, 7, 0);
    chen(&daThuc1, 6, 3);
    chen(&daThuc1, 5, 4);
    Node* daThuc2 = NULL;
    chen(&daThuc2, 3, 1);
    chen(&daThuc2, -7, 2);
    chen(&daThuc2, 2, 3);
    inDaThuc(daThuc1);
    inDaThuc(daThuc2);
    double x = 2;
    cout << "Gia tri tai x = " << x << " la: " << tinhGiaTri(daThuc1, x) << endl;
    Node* ketQuaCong = congDaThuc(daThuc1, daThuc2);
    cout << "Tong hai da thuc: ";
    inDaThuc(ketQuaCong);
    return 0;
}