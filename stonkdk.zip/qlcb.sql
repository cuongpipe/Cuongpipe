﻿create database qlcb;
go
use qlcb;
go
CREATE TABLE TaiKhoan (
    tendangnhap NVARCHAR(50) PRIMARY KEY,
    matkhau NVARCHAR(50) NOT NULL
);

CREATE TABLE donvi (
    MaDonVi INT PRIMARY KEY IDENTITY,
    tendonvi NVARCHAR(100) NOT NULL
);



CREATE TABLE NgachCongTac (
    MaNgach INT PRIMARY KEY IDENTITY,
    tenngach NVARCHAR(100) NOT NULL
);

CREATE TABLE CanBo (
    MaSo INT PRIMARY KEY IDENTITY,
    HoTen NVARCHAR(100) NOT NULL,
    NgaySinh DATE,
    GioiTinh NVARCHAR(10),
    MaDonVi INT,
    MaNgach INT,
    HeSoLuong FLOAT,
    FOREIGN KEY (MaDonVi) REFERENCES donvi(MaDonVi),
    FOREIGN KEY (MaNgach) REFERENCES NgachCongTac(MaNgach)
);

-- Bảng TaiKhoan
INSERT INTO TaiKhoan (tendangnhap, matkhau) VALUES
(N'admin', N'1'),
(N'user1', N'1'),
(N'user2', N'1');

-- Bảng donvi
INSERT INTO donvi (tendonvi) VALUES
(N'Phòng Kế Toán'),
(N'Phòng Nhân Sự'),
(N'Phòng Đào Tạo');

-- Bảng NgachCongTac
INSERT INTO NgachCongTac (tenngach) VALUES
(N'Giảng viên'),
(N'Nhân viên'),
(N'Quản lý');

-- Bảng CanBo
INSERT INTO CanBo (HoTen, NgaySinh, GioiTinh, MaDonVi, MaNgach, HeSoLuong) VALUES
(N'Nguyễn Văn A', '1980-05-20', N'Nam', 1, 1, 3.2),
(N'Trần Thị B', '1985-08-15', N'Nữ', 2, 2, 2.8),
(N'Lê Văn C', '1990-12-01', N'Nam', 3, 3, 4.0),
(N'Phạm Thị D', '1992-03-10', N'Nữ', 1, 2, 3.5);