﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace qlbay
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
            dtp_tgdat .CustomFormat = "dd/MM/yyyy HH:mm";
            dtp_tgdat.ShowUpDown = true;
            LoadComboBoxMakh();
            thôngTinĐặtVéToolStripMenuItem.ForeColor = Color.Blue;
            //ẩn tổng số tiền trước
           // label_tongsotiendat.Visible = false;
        }

 

        private void cb_loc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedName = cb_loc.SelectedItem.ToString();
            FilterByTenNhanVien(selectedName);
        }


        //xử lý sự kiện khi chọn một khách hàng trong combobox
        private void LoadComboBoxMakh()
        {
            string connectionString = "Data Source=xr;Initial Catalog=qlbay;Integrated Security=True;";
            //chỉ lấy các idkhach 1 lần duy nhất thui
            string query = "SELECT DISTINCT idkhach FROM datve";

            cb_loc.Items.Clear();
            cb_loc.Items.Add("Tất cả");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cb_loc.Items.Add(reader["idkhach"].ToString());
                }
            }

            cb_loc.SelectedIndex = 0;
        }


        private void LoadData()
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                string sql = "SELECT * FROM datve";
                SqlDataAdapter gridviu = new SqlDataAdapter(sql, conn);
                gridviu.Fill(dt);
                grid_datve.RowHeadersVisible = false;
                grid_datve.DataSource = dt;
                //vứt dòng trống cuối cùng
                grid_datve.AllowUserToAddRows = false;
            }
            LoadComboBoxMakh();

            

        }


        //lọc theo id khách hàng và hiện lên grid view
        private void FilterByTenNhanVien(string idkhach)
        {
            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                string sql;
                string sql2="";
                if (idkhach == "Tất cả")
                {
                    sql = "SELECT * FROM datve";
                }
                else
                {
                    sql = "SELECT * FROM datve WHERE idkhach = @idkhach";
                    //sql = "SELECT MaNV, HoTen, DiaChi, FORMAT(NgaySinh, 'dd/MM/yyyy') AS NgaySinh, DienThoai FROM nhanvien WHERE HoTen = @HoTen";

                    //hiện tổng số tiền này
                    sql2 = "SELECT SUM(giatien) AS TongTien FROM datve WHERE idKhach = '" + idkhach + "'";


                }

                SqlCommand cmd = new SqlCommand(sql, conn);
                if (idkhach != "Tất cả")
                    cmd.Parameters.AddWithValue("@idkhach", idkhach);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                grid_datve.RowHeadersVisible = false; // ẩn cột lỏ đầu tiên
                adapter.Fill(dt);
                grid_datve.DataSource = dt;
                //vứt dòng trống cuối cùng
                grid_datve.AllowUserToAddRows = false;
                //tăng kích thước cột thoigiandatve
                grid_datve.Columns["thoigiandatve"].Width = 200;

                conn.Open();
                if (!string.IsNullOrEmpty(sql2))
                {
                    SqlCommand cmd2 = new SqlCommand(sql2, conn);
                    object result2 = cmd2.ExecuteScalar();
                    //ép kiểu về chuỗi
                    string result3 = result2.ToString();
                    if(!string.IsNullOrEmpty(result3))
                    {
                        // hiển thị lại label
                        //label_tongsotiendat.Visible = true;
                        label_tongsotiendat.Text = result2.ToString() + " VND";
                    }
                    else
                    {
                       // label_tongsotiendat.Visible = true;
                        label_tongsotiendat.Text = "0 VND";
                    }

                     
                }

            }
        }





        private void btn_them_Click(object sender, EventArgs e)
        {
            // Kiểm tra ID hợp lệ phải là sô nguyên
            if (!int.TryParse(txt_idkhach.Text, out int idkhach))
            {
                MessageBox.Show("ID khách phải là số nguyên!");
                return;
            }

            string machuyen = txt_machuyen.Text.Trim();
            double giatien = txt_giatien.Text.Trim() == "" ? 0 : double.Parse(txt_giatien.Text.Trim());
            string dt_tgdat = dtp_tgdat.Value.ToString("dd/MM/yyyy HH:mm"); // lấy ngày và giờ luôn


            //kiểm tra id khách và họ tên đã được nhập chưa 
            if (idkhach == 0 || string.IsNullOrEmpty(machuyen))
            {
                MessageBox.Show("id khách và mã chuyến không được để trống!");
                return;
            }

            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                conn.Open();

                //// Kiểm tra xem mã khách hàng đã tồn tại chưa
                string checkSql = "SELECT COUNT(*) FROM khach WHERE idkhach = @idkhach";
                SqlCommand checkCmd = new SqlCommand(checkSql, conn);
                checkCmd.Parameters.AddWithValue("@idkhach", idkhach);

                //if ((int)checkCmd.ExecuteScalar() > 0)
                //{
                //    MessageBox.Show("Mã chuyến đã tồn tại! Vui lòng nhập mã khác.");
                //    conn.Close();
                //    return;
                //}



                // Nếu chưa tồn tại, thực hiện thêm mới
                //string query = @"";
                string sql = "INSERT into datve values('" + idkhach +
                "','" + machuyen + "','" + giatien + "','" + dt_tgdat + "')";

                //
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("đã thêm thành công");
                cleartextbox();
                //LoadData(); // hiện tất cả ra bảng
                FilterByTenNhanVien(idkhach.ToString());
                //conn.Close();
            }
        }

        private void cleartextbox()
        {
            txt_giatien.Text = "";
            txt_idkhach.Text = "";
            txt_machuyen.Text = "";
        }


        private void thôngTinKháchĐặtVéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide(); // hoặc this.Close();

        }
    }
}
