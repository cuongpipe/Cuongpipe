#include<iostream>
#include<queue>
using namespace std;

struct Person {
	string name;
	int yearOfBirth;
};

struct FT {
	Person data;
	FT *child, *sibling;
	// child: luu dia chi nut con dau tien (neu co)
	// sibling: luu dia chi nut em lien ke (neu co)
};

FT* taoCay(Person p) {
	FT* root = new FT;
	root->data = p;
	root->child = nullptr;
	root->sibling = nullptr;
	return root;
}

// Hàm thêm 1 người con vào node có tên là 'parentName' (thêm vào cuối danh sách con)
void addChild(FT* root, string parentName, Person childPerson) {
	if (!root) return;

	if (root->data.name == parentName) {
		FT* newNode = new FT{childPerson, nullptr, nullptr};
		if (!root->child) {
			root->child = newNode;
		} else {
			FT* p = root->child;
			while (p->sibling)
				p = p->sibling;
			p->sibling = newNode;
		}
		return;
	}

	FT* child = root->child;
	while (child) {
		addChild(child, parentName, childPerson);
		child = child->sibling;
	}
}









// duyet theo chieu sau
void DFS(FT *root) {
	if(root != nullptr) {
		cout << root->data.name <<" "<< root->data.yearOfBirth << " ";

		FT *r = root->child;  // Gán đúng giá trị ban đầu
		while(r != nullptr) {
			DFS(r);
			r = r->sibling;
		}
	}
}
//Cây tổng quát không có chu trình (các nhánh không quay ngược lại tổ tiên).
//Mỗi node chỉ có một đường đi duy nhất từ gốc đến nó.
//Nên bạn không cần đánh dấu "đã thăm" như trong đồ thị.


// duyet theo chieu rong
void BFS(FT *root) {
	queue<FT*> q;
	FT *r;
	if (root != nullptr) {
		q.push(root);
		while (!q.empty()) {
			r = q.front();
			q.pop();
			cout << r->data.name <<" "<< r->data.yearOfBirth << " ";

			r = r->child;
			while (r != nullptr) {
				q.push(r);
				r = r->sibling;
			}
		}
	}
}

void inCay(FT* root, int space = 0) {
	if (root == nullptr) return;
	cout << string(space, ' ') << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;
	FT* child = root->child;
	while (child != nullptr) {
		inCay(child, space + 4);
		child = child->sibling;
	}
}


//tim nguoi name x trong cay tai p.
//Sau do tim nguoi name y trong cay nut goc la p.
bool isChild(FT* root, string x, string y) {
	if (!root) return false;
	if (root->data.name == x) {
		FT* child = root->child;
		while (child != nullptr) {
			if (child->data.name == y)
				return true;
			child = child->sibling;
		}
		return false;
	}
	FT* child = root->child;
	while (child != nullptr) {
		if (isChild(child, x, y))
			return true;
		child = child->sibling;
	}
	return false;
}


//g) Them nguoi q vao con cua nguoi name x trong cay. Biet rang cac nut con cua mot nguoi
//duoc sap theo thu tu tang cua nam sinh.
//Goi y: tim nguoi name x trong cay tai nut p. Duyet cac nut con cua nut p de tim vi tri phu
//hop them nguoi q vao.


FT* search(FT* root, string name) {
	FT *p, *result;
	if (!root) return nullptr;

	if (root->data.name == name)
		return root;
	else {
		p = root->child;
		while (p) {
			result = search(p, name);  // gọi đệ quy
			if (result) return result;
			else p = p->sibling;
		}
		return nullptr; // không tìm thấy trong tất cả nhánh con
	}
}

void insertChild(FT* root, string parentName, Person personToInsert) {
	FT* parent = search(root, parentName);

	if (parent != nullptr) {
		FT* newNode = new FT{personToInsert, nullptr, nullptr};

		// Duyệt danh sách con của node cha để chèn đúng vị trí theo năm sinh
		FT* prev = nullptr;
		FT* curr = parent->child;

		while (curr != nullptr && curr->data.yearOfBirth < newNode->data.yearOfBirth) {
			prev = curr;
			curr = curr->sibling;
		}

		if (prev == nullptr) {
			// Thêm vào đầu danh sách con
			newNode->sibling = parent->child;
			parent->child = newNode;
		} else {
			// Thêm vào giữa hoặc cuối
			newNode->sibling = curr;
			prev->sibling = newNode;
		}
	}
	return;
}




//h) Liet ke con, chau cua mot nguoi co ho name x.
//Goiy: tim nguoi name x trong cay tai nut p. Sau do in tat ca nhung cay co goc la con cua
//p.
void printDescendants(FT* root, string x) {
	if (!root) return;
	if (root->data.name == x) {
		FT* child = root->child;
		while (child) {
			cout << "Con: " << child->data.name << " (" << child->data.yearOfBirth << ")" << endl;
			FT* grandchild = child->child;
			while (grandchild) {
				cout << "  Chau: " << grandchild->data.name << " (" << grandchild->data.yearOfBirth << ")" << endl;
				grandchild = grandchild->sibling;
			}
			child = child->sibling;
		}
		return;
	}

	FT* child = root->child;
	while (child) {
		printDescendants(child, x);
		child = child->sibling;
	}
}


//i) In nhung nguoi thuoc the he thu k.
void printByLevel(FT* root, int k, int level = 1) {


	if (!root) return;

	if (level == k) {
		cout << root->data.name << " (" << root->data.yearOfBirth << ")" << endl;
	}

	FT* child = root->child;
	while (child) {
		printByLevel(child, k, level + 1);// đệ quy

		child = child->sibling;
	}
}


//j) Tinh bac cua cay.
//Goiy: duyet tung nut, moi nut dem so nut con sau do chon so nut con lon nhat.
int degree(FT* root) {
	if (!root) return 0;

	int count = 0;
	FT* child = root->child;
	while (child) {
		count++;
		child = child->sibling;
	}

	int maxChild = count;
	child = root->child;
	while (child) {
		int deg = degree(child);
		if (deg > maxChild)
			maxChild = deg;
		child = child->sibling;
	}

	return maxChild;
}


// k) Xoa nguoi tren cay co name x (x khong phai ong to cua dong ho).
// Goiy: Tim nguoi name x tai nut p va p1 la nut cha cua p va p2 la nut anh lien ke cua p. Neu
// p la nut con truong thi chuyen nut con cua p1 la em lien ke cua p. Nguoc lai chuyen em
// lien ke cua p2 la em lien ke cua p. Sau do xoa toan bo cay nut goc la p.
// Xóa cây con của một nút
FT* findByName(FT* root, const string& name) {
	if (!root) return nullptr;
	if (root->data.name == name) return root;
	for (FT* child = root->child; child; child = child->sibling) {
		FT* found = findByName(child, name);
		if (found) return found;
	}
	return nullptr;
}
//cách 1
//void deleteByName(FT* root, const string& x) {
//	if (!root || root->child == nullptr) return;
//
//	FT* curr = root->child;
//	FT* prev = nullptr;
//
//	while (curr != nullptr) {
//		FT* next = curr->sibling; // lưu lại trước để an toàn
//
//		if (curr->data.name == x) {
//			if (prev == nullptr) {
//				root->child = curr->sibling;
//			} else {
//				prev->sibling = curr->sibling;
//			}
//			return; // THOÁT NGAY khi đã xóa
//		} else {
//			// Gọi đệ quy trước khi gán prev/curr
//			deleteByName(curr, x);
//		}
//
//		prev = curr;
//		curr = next;
//	}
//}





//cách2
void deleteByName(FT* &root, string name) {
	if(root) {
		FT *x = nullptr;
// tìm node cần xóa
		queue<FT*> q;
		q.push(root);
		while(!q.empty()) {
			FT* p = q.front();
			q.pop();
			if(p->child) { // nếu p có con
				FT* k = p->child;
				while(k) {
					if(k->data.name == name) {
// gán nốt cha
						x = p;
					}
					q.push(k);
					k = k->sibling;
				}
			}
		}

		if (x) {
			FT *deleteByName = x->child;
// th1: nút cần xóa nối trực tiếp vs node cha
			if(deleteByName->data.name == name) {
// liên kết con trỏ x child tới node khác sau node cần xóa

				x->child = deleteByName->sibling;
				delete(deleteByName);
			}
// th2: nút cần xóa không nối vs node cha
// tìm nút cần xóa
			else {
				FT *parentdeleteByName = deleteByName;
				deleteByName = deleteByName->sibling;
				while(deleteByName) {
					if(deleteByName->data.name == name)
						break;
					deleteByName = deleteByName->sibling;
					parentdeleteByName = parentdeleteByName->sibling;
				}
// đổi địa chỉ
				parentdeleteByName->sibling = deleteByName->sibling;
				delete(deleteByName);
			}

		}
	}

}









//**********************************************************************
//cho biet nguoi name x va y co phai la anh em

bool issibling(FT* root, string x, string y) {
	if (root == nullptr) return false;
	FT* r = root->child;
	bool chkx = false, chky = false;
	while (r != nullptr) {
		if (r->data.name == x) {
			chkx = true;
			if (chky) return true;
		}
		if (r->data.name == y) {
			chky = true;
			if (chkx) return true;
		}
		r = r->sibling;
	}
	r = root->child;

	while (r != nullptr) {
		bool chk = issibling(r, x, y);
		if (chk) return true;
		r = r->sibling;
	}
	return false;
}

//in thế hệ cây (cách làm 2)
void printLevel(FT* root, int k) {
	if (root != nullptr) {
		if (k == 1)
			cout <<root->data.name <<" "<<root->data.yearOfBirth<<" "<<endl;
		else {
			FT* p = root->child;
			while (p != nullptr) {
				printLevel(p, k-1);
				p = p->sibling;
			}
		}
	}


}

//liet ke tat ca con cua nguoi name x
void printChildren(FT* root, string x) {
	FT* r = search(root, x);
	if (r != nullptr) {
		FT* p = r->child;
		while (p != nullptr) {
			cout << p->data.name << endl;
			p = p->sibling;
		}
	}
}


// tinh the he cua nguoi name x
int levelX(FT* root, string x) {
	if (root == nullptr) return 0;
	else if (root->data.name == x) return 1;
	else {
		FT* p = root->child;
		while (p != nullptr) {
			int h = levelX(p, x);
			if (h > 0) return h + 1;
			else p = p->sibling;
		}
		return 0; // k tim thay nguoi name x
	}
}

//kiem tra nguoi name y co phai con cua nguoi name x khong ?
bool isParent(FT* root, string x, string y) {
	FT* r;
	r = search(root, x);
	if (r == nullptr) return false;
	else {
		FT* p = r->child;
		while (p != nullptr) {
			if (p->data.name == y) return true;
			else p = p->sibling;
		}
		return false;
	}
}


//dem so nguoi trong cay gia pha
int countPersons(FT *root) {
	if(root == nullptr) return 0;
	else {
		int d = 1;
		FT *p = root->child;
		while (p != nullptr) {
			d = d + countPersons(p);
			p = p->sibling;
		}
		return d;
	}
}


//tinh so the he cua cay gia pha
int height(FT *root) {
	if(root == nullptr) return 0;
	else {
		int h, max = 0;
		FT *p = root->child;
		while (p != nullptr) {
			h = height(p);
			if (h > max) max = h;
			p = p->sibling;
		}
		return max + 1;
	}
}

void themConkss(FT* root, string parentName, Person personToInsert) {
	FT* parent = search(root, parentName);

	if (parent != nullptr) {
		FT* newNode = new FT{personToInsert, nullptr, nullptr};

		// Duyệt danh sách con của node cha để chèn đúng vị trí theo năm sinh
		FT* prev = nullptr;
		FT* curr = parent->child;

		//Đứa con đang duyệt (curr) có năm sinh nhỏ hơn đứa con mới muốn thêm (newNode) hay không?
		//Miễn là đứa con đang xét (curr) sinh trước (năm sinh < newNode) thì tiếp tục đi tiếp (lặp).
		while (curr != nullptr && curr->data.yearOfBirth < newNode->data.yearOfBirth) {
			prev = curr;
			curr = curr->sibling;//dich den dua con tiep theo
			//prev là con trước, sau vòng lặp curr thành con
		}


		if (prev == nullptr) {
			// Thêm vào đầu danh sách con
			newNode->sibling = parent->child;
			parent->child = newNode;
		} else {
			// Thêm vào giữa hoặc cuối
			newNode->sibling = curr;
			prev->sibling = newNode;
		}
	}
	return;
}

//Tìm phần tử chứa nhiều con nhất trừ nút gốc
void isMostsibling(FT* root, int &max, FT*& maxNode) {
	if(root) {
		queue<FT*> q;
		root = root->child;
		while (root) {
			q.push(root);
			root = root->sibling;
		}
// xét từng thằng trong queue
		while(!q.empty()) {
			FT *p = q.front();
			q.pop();
// nếu thằng p mà nó có con thì cho con nó vô q và đếm số con
			if(p->child) {
				FT *childP = p->child;
				int count = 0;
				while(childP) {
					count++;
					q.push(childP);
					childP = childP->sibling;
				}
				if(count > max) {
					max = count;
					maxNode = p;
				}
			}
		}
	}
}

int main() {

	FT* root = taoCay({"Nguyen A", 1900});
	addChild(root, "Nguyen A", {"Nguyen B", 1930});
	addChild(root, "Nguyen A", {"Nguyen C", 1935});

	addChild(root, "Nguyen B", {"Nguyen D", 1995});
	addChild(root, "Nguyen B", {"Nguyen E", 1960});
	addChild(root, "Nguyen B", {"Nguyen F", 1965});

	addChild(root, "Nguyen C", {"Nguyen G", 1965});
	addChild(root, "Nguyen C", {"Nguyen H", 1970});

//duyệt theo chiều sâu là duyệt:
//Gốc → con đầu → sâu xuống hết → quay lên → duyệt em kế tiếp
	cout << endl << "Duyet theo chieu sau" << endl;
	DFS(root);


//Duyệt theo chiều rộng là duyệt: từng tầng:
//Level 1: A
//Level 2: B, C
//Level 3: D, E, F (con của B), G, H (con của C)
	cout << endl << "Duyet theo chieu rong" << endl;
	BFS(root);

	cout << endl;

	cout << "In cay pha he (in ra dang cay):" << endl;
	inCay(root);
	cout << endl;

	// Kiem tra la con hay khong
	cout << "Kiem tra la con: " << endl;
	
	if (isChild(root, "Nguyen A", "Nguyen B")) {
		cout << "Nguyen B la con cua Nguyen A" << endl;
	} 
	else {
		cout << "Nguyen B khong la con cua Nguyen A" << endl;
	}

	if (isChild(root, "Nguyen B", "Nguyen C")) {
		cout << "Nguyen C la con cua Nguyen B" << endl;
	} 
	else {
		cout << "Nguyen C khong la con cua Nguyen B" << endl;
	}


	// Them nguoi vao cay theo thu tu tang dang cua nam sinh
	Person newPerson = {"Nguyen J", 1966};
	string parentName = "Nguyen C";
	insertChild(root, parentName, newPerson);
	cout << "In cay sau khi them nguoi name " << newPerson.name <<" co nam sinh " << newPerson.yearOfBirth << " vao con cua " <<parentName << endl;
	inCay(root);
	cout << endl;

	// In con va chau cua nguoi co name Nguyen C
	cout << "Con va chau cua Nguyen C: " << endl;
	printDescendants(root, "Nguyen C");

	// In nhung nguoi thuoc the he thu 2
	int k2 = 1;
	cout << "Nhung nguoi thuoc the he thu" << k2 << ": " << endl;
	printByLevel(root, k2);

	// Tinh bac cua cay
	cout << "Bac cua cay: " << degree(root) << endl;

	// Xoa nguoi co name Nguyen D
	if (root->data.name == "Nguyen D") {
		cout << "Khong the xoa ong to dong ho!" << endl;
	} else {
		deleteByName(root, "Nguyen D");
	}

	if (root) {
		cout << "In cay sau khi xoa Nguyen D: " << endl;
		inCay(root);
	}


	//kiem tra c va d co phai anh ems
	string c = "Nguyen A";
	string d = "Nguyen E";
	if(issibling(root, c, d) == true) {
		cout <<"Nguoi " << c <<" va nguoi " << d <<" la anh em !" << endl;
	} 
	else cout <<"Nguoi " << c <<" va nguoi " << d <<" khong phai anh em !" << endl;
 
 
	//in thế hệ cây cách 2
	int x3 = 1;
	cout <<"In the he cay cach 2 nguoi thuoc the he thu " << x3 << endl;
	printLevel(root, x3);

	//liet ke tat ca con nguoi name x
	string x4 = "Nguyen A";
	cout << "Liet ke con cua nguoi name " << x4 << endl;
	printChildren(root, x4);

    //tinh the he cua nguoi ten x
	string x5 = "Nguyen A";
	if(levelX(root, x5) == 0) {
		cout <<"Khong tim thay nguoi name "<< x5 << endl;
	} 
	else {
		cout <<"Nguoi name " << x5 <<" thuoc the he " << levelX(root, x5) << endl;
	}


	//kiem tra nguoi name y co phai con cua nguoi name x khong ?
	string x6 = "Nguyen A";
	string y6 = "Nguyen D";
	if(isParent(root, x6, y6)) {
		cout << "Nguoi name " << y6 << " la con cua nguoi name "<< x6 << endl;
	} 
	else {
		cout << "Nguoi name " << y6 << " khong phai la con cua nguoi name "<< x6 << endl;
	}

	//so nguoi trong cay gia pha
	cout << "so nguoi trong cay gia pha " << countPersons(root) << endl;

	//tinh so the he cua cay gia pha, tinh bac cua cay gia pha
	cout << "so the he (bac) cua cay gia pha " << height(root) << endl;

	//
	//themConkss(FT* root, string parentName, Person personToInsert)

	Person newPerson2 = {"Nguyen L", 1955};
	string parentName2 = "Nguyen C";
	themConkss(root, parentName2, newPerson2);
	cout << "In cay sau khi them nguoi name " << newPerson2.name <<" co nam sinh " << newPerson2.yearOfBirth << " vao con cua Nguyen C:" << endl;
	inCay(root);
	cout << endl;
	
	// Tìm người có nhiều con nhất (trừ nút gốc)
	int max = -1;
	FT* maxNode = nullptr;
	isMostsibling(root, max, maxNode);

	if (maxNode != nullptr) {
		cout << "Nguoi co nhieu con nhat (tru nut goc): " << maxNode->data.name
		     << " voi " << max << " con." << endl;
	} 
	else {
		cout << "Khong co nguoi nao co con hoac cay rong!" << endl;
	}

	return 0;
}