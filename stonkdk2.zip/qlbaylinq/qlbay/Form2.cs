﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq.Mapping;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static qlbay.Form1;
using System.Threading;
using static qlbay.Form3;
using static qlbay.Form2;

namespace qlbay
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadData();
            thôngTinKháchĐặtVéToolStripMenuItem.ForeColor = Color.Blue;
        }


        [Table(Name = "khach")]

        public class khach
        {
            //tất cả lấy từ database
            [Column(IsPrimaryKey = true, Name = "idkhach")]
            public int idkhach { get; set; }
            
            [Column(Name = "hoten")]
            public string hoten { get; set; }
            
            [Column(Name = "ngaysinh")]
            public DateTime ngaysinh { get; set; }
            
            [Column(Name = "diachi")]
            public string diachi { get; set; }

            [Column(Name = "gioitinh")]
            public string gioitinh { get; set; }


        }

        public class QLCBDataContext : DataContext
        {
            public QLCBDataContext(string connection) : base(connection) { }
            public Table<khach> khachs;
        }

        private void LoadData()
        {
            DataTable dt = new DataTable();
            List<object> ketQua;

            string connStr = "Data Source =xr;Initial Catalog=qlbay;Integrated Security=True;";

            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {
                var query = from dv in db.khachs
                            select new
                            {
                                dv.idkhach,
                                dv.hoten,
                                dv.ngaysinh,
                                dv.diachi,
                                dv.gioitinh
                            };

                ketQua = query.ToList<object>();
                //gridviu.Fill(dt);
                grid_thongtin.RowHeadersVisible = false;
                grid_thongtin.DataSource = ketQua;
                grid_thongtin.AllowUserToAddRows = false;
            }

            //load các tùy chọn trong combobox bằng hàm dưới
           // LoadComboBoxMakh(); // extension thui
        }




        private void btn_them_Click(object sender, EventArgs e)
        {

            // Kiểm tra ID hợp lệ
            if (!int.TryParse(txt_idkhach.Text, out int idkhach))
            {
                MessageBox.Show("ID khách phải là số nguyên!");
                return;
            }

            string hoten = txt_hoten.Text.Trim();
            //string dt_ngaysinh = dtp_ngaysinh.Value.ToString("yyyy-MM-dd"); // Không cần giờ phút giây nếu không cần
            
            DateTime dt_ngaysinh = dtp_ngaysinh.Value; // Không cần giờ phút giây nếu không cần
            string diachi = txt_diachi.Text.Trim();

            //khởi tạo cái biến gioitinh trống để lưu giói tính
            string gioitinh = "";
            if (rd_btn_nam.Checked)
            {
                gioitinh = "nam";
            }
            else if (rd_btn_nu.Checked)
            {
                gioitinh = "Nữ";
            }

            //kiểm tra id khách và họ tên đã được nhập chưa 
            if (idkhach == 0 || string.IsNullOrEmpty(hoten))
            {
                MessageBox.Show("id khách và Họ tên không được để trống!");
                return;
            }

            string connStr = "Data Source =xr;Initial Catalog=qlbay;Integrated Security=True;";

            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {

                // Kiểm tra xem mã khách hàng đã tồn tại chưa
                // LINQ to SQL - kiểm tra idkhach đã tồn tại chưa
                var existing = (from k1 in db.khachs
                                where k1.idkhach == idkhach
                                select k1).FirstOrDefault();

                if (existing != null)
                {
                    MessageBox.Show("ID khách đã tồn tại! Vui lòng nhập ID khác.");
                    return;
                }

                // Nếu chưa tồn tại, thực hiện thêm mới
                // Tạo đối tượng mới
                khach k = new khach
                {
                    idkhach = idkhach,
                    hoten = hoten,
                    ngaysinh = dt_ngaysinh,//nó tự nhận thoigiandatve là datetime
                    diachi = diachi,
                    gioitinh = gioitinh
                };

                // Thêm vào bảng
                db.khachs.InsertOnSubmit(k);

                // Thực hiện lưu vào DB
                db.SubmitChanges();
                MessageBox.Show("đã thêm thành công");
                LoadData();
                //conn.Close();
            }

            MessageBox.Show("in kq: " + dt_ngaysinh);

        }



        private void btn_capnhat_Click(object sender, EventArgs e)
        {



            if (string.IsNullOrEmpty(txt_idkhach.Text))
            {
                MessageBox.Show("Vui lòng chọn một khách để sửa.");
                return;
            }

            string connStr = "Data Source =xr;Initial Catalog=qlbay;Integrated Security=True;";

            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {
                int idkhach = txt_idkhach.Text.Trim() == "" ? 0 : int.Parse(txt_idkhach.Text.Trim());
                string hoten = txt_hoten.Text.Trim();
                DateTime ngaysinh = dtp_ngaysinh.Value; // Không cần giờ phút giây nếu không cần
                string diachi = txt_diachi.Text.Trim();
                
                //khởi tạo cái biến gioitinh trống . để lưu giói tính
                string gioitinh = "";
                if (rd_btn_nam.Checked)
                {
                    gioitinh = "nam";
                }
                else if (rd_btn_nu.Checked)
                {
                    gioitinh = "nữ";
                }

                //kiểm tra xem khách tồn tại k
                var existing = (from k1 in db.khachs
                                where k1.idkhach == idkhach
                                select k1).FirstOrDefault();

                if (existing == null)
                {
                    MessageBox.Show("ID khách không tồn tồn tại! Vui lòng chọn ID khác.");
                    return;
                }
                //cách 2:
                // Kiểm tra tồn tại
                    //var checkExist = db.khachs.Any(k => k.idkhach == idkhach);
                    //if (!checkExist)
                    //{
                    //    MessageBox.Show("ID khách không tồn tại! Vui lòng chọn ID khác.");
                    //    return;
                    //}





                // Lấy khách để cập nhật
                var khachUpdate = db.khachs.Single(k => k.idkhach == idkhach);

                khachUpdate.hoten = hoten;
                khachUpdate.ngaysinh = ngaysinh;
                khachUpdate.diachi = diachi;
                khachUpdate.gioitinh = gioitinh;

                db.SubmitChanges();

                MessageBox.Show("Cập nhật nhân viên thành công!");
                LoadData();
            }
        }



        private void btn_xoa_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txt_idkhach.Text) || string.IsNullOrEmpty(txt_hoten.Text) ||
    string.IsNullOrEmpty(dtp_ngaysinh.Text) || string.IsNullOrEmpty(txt_diachi.Text))
            {
                MessageBox.Show("Vui lòng chọn khách hàng để xóa!");
                return;
            }

            string connStr = "Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;";


            int idkhach = txt_idkhach.Text.Trim() == "" ? 0 : int.Parse(txt_idkhach.Text.Trim());


            try
            {
                QLCBDataContext db = new QLCBDataContext(connStr);
                //kiểm tra tồn tịa khum
                //var existing = (from k1 in db.khachs
                //                where k1.idkhach == idkhach
                //                select k1).FirstOrDefault();

                //if (existing == null)
                //{
                //    MessageBox.Show("ID khách không tồn tồn tại! Vui lòng chọn ID khác.");
                //    return;
                //}


                DialogResult r = MessageBox.Show("Xác nhận xoá khách này?", "Xác nhận", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    // Tìm khách cần xóa
                    var khachCanXoa = db.khachs.FirstOrDefault(k => k.idkhach == idkhach);

                    ////cách 2
                    //if (khachCanXoa == null)
                    //{
                    //    MessageBox.Show("ID khách không tồn tại! Vui lòng kiểm tra lại.");
                    //    return;
                    //}

                    // Xóa khỏi bảng
                    db.khachs.DeleteOnSubmit(khachCanXoa);
                    db.SubmitChanges();
                    MessageBox.Show("Xóa thành công!");
                    LoadData(); // Cập nhật lại dữ liệu trên lưới
                }
                else
                {
                    MessageBox.Show("Xóa đã bị hủy.");
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message);
            }
        }



        private void grid_thongtin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= grid_thongtin.Rows.Count)
                return; // Không làm gì nếu click ngoài vùng hợp lệ vd: nhấn vô ô tiêu đề của cột!
            DataGridViewRow row = grid_thongtin.Rows[e.RowIndex];
            txt_idkhach.Text = row.Cells["idkhach"].Value.ToString();
            txt_hoten.Text = row.Cells["HoTen"].Value.ToString();
            dtp_ngaysinh.Value = Convert.ToDateTime(row.Cells["NgaySinh"].Value);
            txt_diachi.Text = row.Cells["DiaChi"].Value.ToString();

            if ((row.Cells["gioitinh"].Value.ToString()) == "nam")
            {
                rd_btn_nam.Checked = true; 
            }
            else if ((row.Cells["gioitinh"].Value.ToString()) == "nữ")
            {
                rd_btn_nu.Checked = true;
            }


        }





        // extension thui 
        // tải dữ liệu vào combo để chọn
        private void LoadComboBoxMakh()
        {
            string connectionString = "Data Source=xr;Initial Catalog=qlbay;Integrated Security=True;";
            string query = "SELECT idkhach FROM khach";

            cb_loc.Items.Clear();
            cb_loc.Items.Add("Tất cả");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cb_loc.Items.Add(reader["idkhach"].ToString());
                }
            }

            cb_loc.SelectedIndex = 0;
        }






        //lọc theo id khách hàng và hiện lên grid view
        private void FilterByTenNhanVien(string idkhach)
        {
            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                string sql;

                if (idkhach == "Tất cả")
                {
                    sql = "SELECT * FROM khach";
                }
                else
                {
                    sql = "SELECT * FROM khach WHERE idkhach = @idkhach";
                    //sql = "SELECT MaNV, HoTen, DiaChi, FORMAT(NgaySinh, 'dd/MM/yyyy') AS NgaySinh, DienThoai FROM nhanvien WHERE HoTen = @HoTen";
                }

                SqlCommand cmd = new SqlCommand(sql, conn);
                if (idkhach != "Tất cả")
                    cmd.Parameters.AddWithValue("@idkhach", idkhach);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                grid_thongtin .RowHeadersVisible = false; // ẩn cột lỏ đầu tiên
                adapter.Fill(dt);
                grid_thongtin .DataSource = dt;
                grid_thongtin.AllowUserToAddRows = false;
            }
        }



        //xử lý sự kiện khi chọn một khách hàng trong combobox
        private void cb_loc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedName = cb_loc.SelectedItem.ToString();
            FilterByTenNhanVien(selectedName);
        }

        private void thôngTinĐặtVéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //làm biến mất các nút thừa thãi
            //cb_loc.Visible = false;
            //label6.Visible = false;
      
            Form3 f3 = new Form3();
            f3.ShowDialog();
            this.Hide(); // hoặc this.Close();
            //this.Close();

        }
    }
}
