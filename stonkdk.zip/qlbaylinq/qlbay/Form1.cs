﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using qlbay;

namespace qlbay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [Table(Name = "nhanvien")]

        public class nhanvien
        {
            [Column(IsPrimaryKey = true, Name = "manv")]
            public string manv { get; set; }
            
            [Column(Name = "matkhau")]
            public string matkhau { get; set; }
        }

        public class QLCBDataContext : DataContext
        {
            public QLCBDataContext(string connection) : base(connection) { }
            public Table<nhanvien> nhanviens;
        }


            private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "show")
            {
                button1.Text = "hidden";
                txt_pass.PasswordChar = '\0';
            }
            else
            {
                txt_pass.PasswordChar = '*';
                button1.Text = "show";
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {


            string connStr = @"Data Source=xr;Initial Catalog=qlbay;Integrated Security=True";

            try
            {
                QLCBDataContext db = new QLCBDataContext(connStr);

                var users = (from tk in db.nhanviens
                             where tk.manv.Trim() == txt_user.Text.Trim()
                                && tk.matkhau.Trim() == txt_pass.Text.Trim()
                             select tk);

                
                //lấy kết quả dòng truy vấn đầu
                var user = users.FirstOrDefault();

                if (user != null)
                {
                    MessageBox.Show("Đăng nhập thành công!");
                    Form2 form2 = new Form2();
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Tên đăng nhập/Mật khẩu không hợp lệ!");
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi kết nối CSDL!");
                return;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close(); ;

        }
    }
}
