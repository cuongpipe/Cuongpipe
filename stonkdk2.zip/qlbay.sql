﻿create database qlbay
go
use qlbay
go


create table khach(
  idkhach int primary key,
  hoten nvarchar(50) not null,
  ngaysinh date ,
  diachi nvarchar(50),
  gioitinh nvarchar(50)

)


create table chuyenbay(
 machuyen varchar(50) primary key,
 tenchuyenbay nvarchar(50) not null,
 sochongoi int not null,
)

create table datve(
    idkhach int  not null ,
	machuyen varchar(50) not null,
	giatien float not null,
	thoigiandatve datetime not null,
	FOREIGN KEY (idkhach) REFERENCES khach(idkhach),
	-- nếu mà idkhach không có trong bảng khach thì: 
	--FOREIGN KEY (idkhach) REFERENCES khach(id),
    FOREIGN KEY (machuyen) REFERENCES chuyenbay(machuyen)
)


create table nhanvien(
  manv varchar(50) primary key,
  tennv nvarchar(50) not null,
  sodt int,
  email varchar(50),
  matkhau varchar(50),
  quyentruycap varchar(50),
)

SELECT * FROM khach
insert into khach (idkhach, hoten, ngaysinh, diachi, gioitinh) values
(1, N'nguyễn văn chó 1', '1900-12-19', N'việt nam', N'nam'),
(2, N'nguyễn văn chó 2', '1900-11-19', N'việt nam', N'nam'),
(3, N'nguyễn văn chó 3', '1900-10-19', N'việt nam', N'nam'),
(4, N'nguyễn văn chó 5', '1900-09-19', N'việt nam', N'nam')
select * from khach

insert into chuyenbay values
('cb1', N'chuyến bay 1', 80),
('cb2', N'chuyến bay 2', 80),
('cb3', N'chuyến bay 3', 80),
('cb4', N'chuyến bay 4', 80)

insert into datve values
(1, 'cb1', 200, '2025-12-10 20:10:00'),
(2, 'cb2', 200, '2025-12-10 20:11:00'),
(3, 'cb3', 200, '2025-12-10 20:12:00'),
(4, 'cb4', 200, '2025-12-10 20:13:00')


insert into nhanvien values
('nv1', N'nguyễn nhân viên 1', 0323232323, 'dg@m.l', 'nv1','nv1'),
('nv2', N'nguyễn nhân viên 2', 0323232323, 'dg@m.l', 'nv2','nv2'),
('nv3', N'nguyễn nhân viên 3', 0323232323, 'dg@m.l', 'nv3','nv3'),
('nv4', N'nguyễn nhân viên 4', 0323232323, 'dg@m.l', 'nv4','nv4')


select * from nhanvien

SELECT COUNT(*) FROM khach WHERE idkhach = 1


SELECT DISTINCT idkhach FROM datve

--Mỗi dòng của BangA sẽ được ghép với mọi dòng của BangB
SELECT *
FROM khach
CROSS JOIN chuyenbay;


SELECT *
FROM khach a
JOIN chuyenbay b ON 1 = 1;

select * from datve where idkhach = 1

delete table khach where idkhach =1
