#include <iostream>
using namespace std;

struct Node {
	int data;
	Node* left;
	Node* right;
	Node(int value) {
		data = value;
		left = right = nullptr;
	}
};
// tao cay
Node* taoCay() {
	Node* root = new Node(10);
	root->left = new Node(5);
	root->right = new Node(15);
	root->left->left = new Node(2);
	root->left->right = new Node(7);
	root->right->left = new Node(12);
	root->right->right = new Node(20);
	return root;
}


// a) viet ham kiem tra cay nhi phan cac so nguyen co la cay tim nhi phan khong ?
bool laCayTimKiemNhiPhan(Node* nut, Node* trai, Node* phai) {
	if (nut == nullptr)
		return true;

	if (trai != nullptr && nut->data <= trai->data)
		return false;
	if (phai != nullptr && nut->data >= phai->data)
		return false;

	return laCayTimKiemNhiPhan(nut->left, trai, nut) && laCayTimKiemNhiPhan(nut->right, nut, phai);
}

bool isBinarySearchTree(Node* root) {
	return laCayTimKiemNhiPhan(root, nullptr, nullptr);
}

// b) viet ham kiem tra cay nhi phan cac so nguyen co la cay can bang khong?
int tinhChieuCao(Node* nut) {
	if (nut == nullptr)
		return 0;

	int caoleft = tinhChieuCao(nut->left);
	if (caoleft == -1) return -1;

	int caoright = tinhChieuCao(nut->right);
	if (caoright == -1) return -1;

	int hieu = caoleft - caoright;
	if (hieu < 0) hieu = - hieu;
	if (hieu > 1)
		return -1;

	return (caoleft > caoright ? caoleft : caoright) + 1;
}

bool isBalancedTree(Node* root) {
	return tinhChieuCao(root) != -1;
}

// c) viet ham kiem tra cay nhi phan có la cay can bang hoan toan khong?
int tinhDoSau(Node* nut) {
	int doSau = 0;
	while (nut != nullptr) {
		doSau++;
		nut = nut->left;
	}
	return doSau;
}

bool laCanBangHoanToan(Node* nut, int doSau, int muc) {
	if (nut == nullptr)
		return true;

	if (nut->left == nullptr && nut->right == nullptr)
		return doSau == muc + 1;

	if (nut->left == nullptr or nut->right == nullptr)
		return false;

	return laCanBangHoanToan(nut->left, doSau, muc + 1) && laCanBangHoanToan(nut->right, doSau, muc + 1);
}

bool isCompleteBalancedTree(Node* root) {
	int doSau = tinhDoSau(root);
	return laCanBangHoanToan(root, doSau, 0);
}



int main() {
	Node* root = taoCay();
	
	cout << "La cay tim kiem nhi phan? ";
	if (isBinarySearchTree(root)) {
		cout << "Co" << endl;
	} else {
		cout << "Khong" << endl;
	}

	cout << "La cay can bang? ";
	if (isBalancedTree(root)) {
		cout << "Co" << endl;
	} else {
		cout << "Khong"<< endl;
	}

	cout << "La cay can bang hoan toan? ";

	if (isCompleteBalancedTree(root)) {
		cout << "Co"<< endl;
	} else {
		cout << "Khong"<< endl;
	}

	return 0;
}
