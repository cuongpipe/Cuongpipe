﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using qlbay;

namespace qlbay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "show")
            {
                button1.Text = "hidden";
                txt_pass.PasswordChar = '\0';
            }
            else
            {
                txt_pass.PasswordChar = '*';
                button1.Text = "show";
            }
        }
        private void btn_login_Click(object sender, EventArgs e)
        {


            SqlConnection conn = new SqlConnection("Data Source=xr;Initial Catalog=qlbay;Integrated Security=True");
            SqlDataReader rdr = null;
            bool OK = false;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM nhanvien", conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (txt_user.Text.Trim() == rdr["manv"].ToString().Trim())
                    {
                        if (txt_pass.Text.Trim() == rdr["matkhau"].ToString().Trim())
                        {
                            OK = true;
                            break;
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi kết nối CSDL!");
                return;
            }
            finally
            {
                if (rdr != null) rdr.Close();
                if (conn != null) conn.Close();
            }

            if (OK)
            {
                MessageBox.Show("Đăng nhập thành công!");
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Tên đăng nhập/Mật khẩu không hợp lệ!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close(); ;

        }
    }
}
