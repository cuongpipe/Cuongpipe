#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

//Hay khai bao to chuc du lieu vector thua
struct Node {
	int chiSo;
	double giaTri;
	Node* tiep;
};

//Ham tao mot node moi cho vector thua
Node* taoNode(int chiSo, double giaTri) {
	Node* nodeMoi = new Node;
	nodeMoi->chiSo = chiSo;
	nodeMoi->giaTri = giaTri;
	nodeMoi->tiep = nullptr;
	return nodeMoi;
}

//Ham them mot node vao cuoi danh sach lien ket
void themNode(Node*& dau, int chiSo, double giaTri) {
	if (dau == nullptr) {
		dau = taoNode(chiSo, giaTri);
		return;
	}
	Node* tam = dau;
	while (tam->tiep != nullptr) {
		tam = tam->tiep;
	}
	tam->tiep = taoNode(chiSo, giaTri);
}

// e) Chuyen mot vector thanh vector thua
Node* chuyenThanhVectorThua(const vector<double>& vec) {
	Node* dau = nullptr;
	for (size_t i = 0; i < vec.size(); ++i) {
		if (vec[i] != 0) {
			themNode(dau, i, vec[i]);
		}
	}
	return dau;
}

// f) Chuyen tu mot vector thua thanh vector
vector<double> chuyenVeVector(Node* v, size_t kichThuoc) {
	vector<double> vec(kichThuoc, 0);
	while (v != nullptr) {
		vec[v->chiSo] = v->giaTri;
		v = v->tiep;
	}
	return vec;
}

// a) Cong hai vec to
Node* congVectorThua(Node* v1, Node* v2) {
	Node* ketQua = nullptr;
	while (v1 != nullptr || v2 != nullptr) {
		if (v1 == nullptr || (v2 != nullptr && v1->chiSo > v2->chiSo)) {
			themNode(ketQua, v2->chiSo, v2->giaTri);
			v2 = v2->tiep;
		} else if (v2 == nullptr || v1->chiSo < v2->chiSo) {
			themNode(ketQua, v1->chiSo, v1->giaTri);
			v1 = v1->tiep;
		} else {
			double tong = v1->giaTri + v2->giaTri;
			if (tong != 0) themNode(ketQua, v1->chiSo, tong);
			v1 = v1->tiep;
			v2 = v2->tiep;
		}
	}
	return ketQua;
}

// b) Nhan mot so voi mot vec to
Node* nhanVoSo(Node* v, double so) {
	Node* ketQua = nullptr;
	while (v != nullptr) {
		themNode(ketQua, v->chiSo, v->giaTri * so);
		v = v->tiep;
	}
	return ketQua;
}

// c) Tich vo huong cua hai vec to
double tichVoHuong(Node* v1, Node* v2) {
	double ketQua = 0;
	while (v1 != nullptr && v2 != nullptr) {
		if (v1->chiSo < v2->chiSo) {
			v1 = v1->tiep;
		} else if (v1->chiSo > v2->chiSo) {
			v2 = v2->tiep;
		} else {
			ketQua += v1->giaTri * v2->giaTri;
			v1 = v1->tiep;
			v2 = v2->tiep;
		}
	}
	return ketQua;
}

// d) Tinh mo dun cua mot vec to
double moDun(Node* v) {
	double tong = 0;
	while (v != nullptr) {
		tong += v->giaTri * v->giaTri;
		v = v->tiep;
	}
	return sqrt(tong);
}

// Ham in vector thua ra man hinh
void inVectorThua(Node* v) {
	while (v != nullptr) {
		cout << "(" << v->chiSo << ", " << v->giaTri << ") ";
		v = v->tiep;
	}
	cout << endl;
}

// Ham giai phong bo nho
void giaiPhong(Node* &dau) {
	while (dau != nullptr) {
		Node* tam = dau;
		dau = dau->tiep;
		delete tam;
	}
}

int main() {

	vector<double> vec = {3, 0, 4, 0, 0, -2};
	vector<double> vec2 = {0, 5, -4, 0, 0, 3};

//e) Chuyen vector thanh vector thua (danh sach lien ket)
	Node* v1 = chuyenThanhVectorThua(vec);
	Node* v2 = chuyenThanhVectorThua(vec2);


	cout << "Chuyen vector v1 tu vector thanh vector thua: ";
	inVectorThua(v1);
	cout << "Chuyen vector v2 tu vector thanh vector thua: ";
	inVectorThua(v2);


//a) Cong hai vector thua v1 va v2
	Node* tong = congVectorThua(v1, v2);
	cout << "Tong 2 vector v1 va v2: ";
	inVectorThua(tong);

//b) Nhan vector thua  voi mot so
	Node* nhan = nhanVoSo(v1, 2);
	cout << "Nhan vector thua v1 voi so 2: ";
	inVectorThua(nhan);
	Node* nhan2 = nhanVoSo(v2, 2);
	cout << "Nhan vector thua v2 voi so 2: ";
	inVectorThua(nhan2);


//c) Tinh tich vo huong cua hai vector thua v1 va v2
	cout << "Tich vo huong 2 vector v1 va v2: " << tichVoHuong(v1, v2) << endl;


//d) Tinh mo dun (do dai) cua vector thua v1
	cout << "Mo dun vector thua v1: " << moDun(v1) << endl;
	cout << "Mo dun vector thua v2: " << moDun(v2) << endl;


//f) Chuyen vector thua ket qua sau khi cong ve dang vector

	vector<double> vecDayDu1 = chuyenVeVector(v1, vec.size());
	vector<double> vecDayDu2 = chuyenVeVector(v2, vec.size());

	cout << "Chuyen vector v1 tu vector thua ve vector: [ ";
	for (double x : vecDayDu1) cout << x << " ";
	cout << "]" << endl;

	cout << "Chuyen vector v2 tu vector thua ve vector: [ ";
	for (double x : vecDayDu2) cout << x << " ";
	cout << "]" << endl;


	// Giai phong bo nho
	giaiPhong(v1);
	giaiPhong(v2);
	giaiPhong(tong);
	giaiPhong(nhan);

	return 0;
}
