﻿namespace qlbay
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grid_thongtin = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thôngTinKháchĐặtVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinĐặtVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txt_idkhach = new System.Windows.Forms.TextBox();
            this.txt_hoten = new System.Windows.Forms.TextBox();
            this.txt_diachi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtp_ngaysinh = new System.Windows.Forms.DateTimePicker();
            this.btn_them = new System.Windows.Forms.Button();
            this.btn_capnhat = new System.Windows.Forms.Button();
            this.rd_btn_nam = new System.Windows.Forms.RadioButton();
            this.rd_btn_nu = new System.Windows.Forms.RadioButton();
            this.btn_xoa = new System.Windows.Forms.Button();
            this.cb_loc = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grid_thongtin)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grid_thongtin
            // 
            this.grid_thongtin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_thongtin.Location = new System.Drawing.Point(25, 38);
            this.grid_thongtin.Margin = new System.Windows.Forms.Padding(2);
            this.grid_thongtin.Name = "grid_thongtin";
            this.grid_thongtin.RowHeadersWidth = 51;
            this.grid_thongtin.RowTemplate.Height = 24;
            this.grid_thongtin.Size = new System.Drawing.Size(463, 243);
            this.grid_thongtin.TabIndex = 0;
            this.grid_thongtin.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_thongtin_CellClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinKháchĐặtVéToolStripMenuItem,
            this.thôngTinĐặtVéToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1057, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thôngTinKháchĐặtVéToolStripMenuItem
            // 
            this.thôngTinKháchĐặtVéToolStripMenuItem.Name = "thôngTinKháchĐặtVéToolStripMenuItem";
            this.thôngTinKháchĐặtVéToolStripMenuItem.Size = new System.Drawing.Size(141, 20);
            this.thôngTinKháchĐặtVéToolStripMenuItem.Text = "Thông tin khách đặt vé";
            // 
            // thôngTinĐặtVéToolStripMenuItem
            // 
            this.thôngTinĐặtVéToolStripMenuItem.Name = "thôngTinĐặtVéToolStripMenuItem";
            this.thôngTinĐặtVéToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.thôngTinĐặtVéToolStripMenuItem.Text = "Thông tin đặt vé";
            this.thôngTinĐặtVéToolStripMenuItem.Click += new System.EventHandler(this.thôngTinĐặtVéToolStripMenuItem_Click);
            // 
            // txt_idkhach
            // 
            this.txt_idkhach.Location = new System.Drawing.Point(621, 38);
            this.txt_idkhach.Name = "txt_idkhach";
            this.txt_idkhach.Size = new System.Drawing.Size(223, 20);
            this.txt_idkhach.TabIndex = 2;
            // 
            // txt_hoten
            // 
            this.txt_hoten.Location = new System.Drawing.Point(621, 86);
            this.txt_hoten.Name = "txt_hoten";
            this.txt_hoten.Size = new System.Drawing.Size(223, 20);
            this.txt_hoten.TabIndex = 3;
            // 
            // txt_diachi
            // 
            this.txt_diachi.Location = new System.Drawing.Point(621, 178);
            this.txt_diachi.Name = "txt_diachi";
            this.txt_diachi.Size = new System.Drawing.Size(223, 20);
            this.txt_diachi.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(553, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "id khách";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(553, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "họ tên";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(553, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "ngày sinh";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(553, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "địa chỉ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(553, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "giới tính";
            // 
            // dtp_ngaysinh
            // 
            this.dtp_ngaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_ngaysinh.Location = new System.Drawing.Point(621, 132);
            this.dtp_ngaysinh.Name = "dtp_ngaysinh";
            this.dtp_ngaysinh.Size = new System.Drawing.Size(223, 20);
            this.dtp_ngaysinh.TabIndex = 14;
            // 
            // btn_them
            // 
            this.btn_them.Location = new System.Drawing.Point(556, 257);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(75, 23);
            this.btn_them.TabIndex = 15;
            this.btn_them.Text = "thêm";
            this.btn_them.UseVisualStyleBackColor = true;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // btn_capnhat
            // 
            this.btn_capnhat.Location = new System.Drawing.Point(659, 256);
            this.btn_capnhat.Name = "btn_capnhat";
            this.btn_capnhat.Size = new System.Drawing.Size(75, 23);
            this.btn_capnhat.TabIndex = 16;
            this.btn_capnhat.Text = "cập nhật";
            this.btn_capnhat.UseVisualStyleBackColor = true;
            this.btn_capnhat.Click += new System.EventHandler(this.btn_capnhat_Click);
            // 
            // rd_btn_nam
            // 
            this.rd_btn_nam.AutoSize = true;
            this.rd_btn_nam.Location = new System.Drawing.Point(621, 211);
            this.rd_btn_nam.Name = "rd_btn_nam";
            this.rd_btn_nam.Size = new System.Drawing.Size(45, 17);
            this.rd_btn_nam.TabIndex = 0;
            this.rd_btn_nam.TabStop = true;
            this.rd_btn_nam.Text = "nam";
            this.rd_btn_nam.UseVisualStyleBackColor = true;
            // 
            // rd_btn_nu
            // 
            this.rd_btn_nu.AutoSize = true;
            this.rd_btn_nu.Location = new System.Drawing.Point(687, 211);
            this.rd_btn_nu.Name = "rd_btn_nu";
            this.rd_btn_nu.Size = new System.Drawing.Size(37, 17);
            this.rd_btn_nu.TabIndex = 1;
            this.rd_btn_nu.TabStop = true;
            this.rd_btn_nu.Text = "nữ";
            this.rd_btn_nu.UseVisualStyleBackColor = true;
            // 
            // btn_xoa
            // 
            this.btn_xoa.Location = new System.Drawing.Point(756, 256);
            this.btn_xoa.Name = "btn_xoa";
            this.btn_xoa.Size = new System.Drawing.Size(75, 23);
            this.btn_xoa.TabIndex = 17;
            this.btn_xoa.Text = "xóa";
            this.btn_xoa.UseVisualStyleBackColor = true;
            this.btn_xoa.Click += new System.EventHandler(this.btn_xoa_Click);
            // 
            // cb_loc
            // 
            this.cb_loc.FormattingEnabled = true;
            this.cb_loc.Location = new System.Drawing.Point(905, 38);
            this.cb_loc.Name = "cb_loc";
            this.cb_loc.Size = new System.Drawing.Size(121, 21);
            this.cb_loc.TabIndex = 18;
            this.cb_loc.SelectedIndexChanged += new System.EventHandler(this.cb_loc_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(878, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "lọc";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 292);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cb_loc);
            this.Controls.Add(this.btn_xoa);
            this.Controls.Add(this.rd_btn_nam);
            this.Controls.Add(this.rd_btn_nu);
            this.Controls.Add(this.btn_capnhat);
            this.Controls.Add(this.btn_them);
            this.Controls.Add(this.dtp_ngaysinh);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_diachi);
            this.Controls.Add(this.txt_hoten);
            this.Controls.Add(this.txt_idkhach);
            this.Controls.Add(this.grid_thongtin);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.grid_thongtin)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView grid_thongtin;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thôngTinKháchĐặtVéToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinĐặtVéToolStripMenuItem;
        private System.Windows.Forms.TextBox txt_idkhach;
        private System.Windows.Forms.TextBox txt_hoten;
        private System.Windows.Forms.TextBox txt_diachi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtp_ngaysinh;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.Button btn_capnhat;
        private System.Windows.Forms.RadioButton rd_btn_nu;
        private System.Windows.Forms.RadioButton rd_btn_nam;
        private System.Windows.Forms.Button btn_xoa;
        private System.Windows.Forms.ComboBox cb_loc;
        private System.Windows.Forms.Label label6;
    }
}