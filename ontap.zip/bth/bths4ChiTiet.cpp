#include <iostream> // Thu vien nhap xuat
#include <cmath> // Thu vien toan hoc
#include <vector> // Thu vien vector
using namespace std; // Su dung namespace std

// Khai bao cau truc du lieu vector thua (danh sach lien ket)
struct Node {
    int chiSo; // Chi so cua phan tu
    double giaTri; // Gia tri cua phan tu
    Node* tiep; // Con tro den node tiep theo
};

// Ham tao mot node moi cho vector thua
Node* taoNode(int chiSo, double giaTri) {
    Node* nodeMoi = new Node; // Cap phat dong cho node moi
    nodeMoi->chiSo = chiSo; // Gan chi so
    nodeMoi->giaTri = giaTri; // Gan gia tri
    nodeMoi->tiep = nullptr; // Ban dau chua noi voi node nao
    return nodeMoi; // Tra ve node moi
}

// Ham them mot node vao cuoi danh sach lien ket
void themNode(Node*& dau, int chiSo, double giaTri) {
    if (dau == nullptr) { // Neu danh sach rong
        dau = taoNode(chiSo, giaTri); // Tao node dau tien
        return;
    }
    Node* tam = dau; // Con tro tam de duyet danh sach
    while (tam->tiep != nullptr) { // Duyet den cuoi danh sach
        tam = tam->tiep;
    }
    tam->tiep = taoNode(chiSo, giaTri); // Them node moi vao cuoi
}

// Chuyen mot vector thanh vector thua
Node* chuyenThanhVectorThua(const vector<double>& vec) {
    Node* dau = nullptr; // Khoi tao danh sach lien ket rong
    for (size_t i = 0; i < vec.size(); ++i) { // Duyet qua vector
        if (vec[i] != 0) { // Chi them cac phan tu khac 0
            themNode(dau, i, vec[i]); // Them vao danh sach
        }
    }
    return dau; // Tra ve danh sach lien ket
}

// Chuyen tu mot vector thua thanh vector day du
vector<double> chuyenVeVector(Node* v, size_t kichThuoc) {
    vector<double> vec(kichThuoc, 0); // Khoi tao vector toan 0
    while (v != nullptr) { // Duyet qua danh sach lien ket
        vec[v->chiSo] = v->giaTri; // Gan gia tri vao vi tri tuong ung
        v = v->tiep; // Chuyen den node tiep theo
    }
    return vec; // Tra ve vector day du
}

// Cong hai vector thua
Node* congVectorThua(Node* v1, Node* v2) {
    Node* ketQua = nullptr; // Khoi tao danh sach ket qua rong
    while (v1 != nullptr || v2 != nullptr) { // Duyet den khi ca hai danh sach rong
        if (v1 == nullptr || (v2 != nullptr && v1->chiSo > v2->chiSo)) {
            themNode(ketQua, v2->chiSo, v2->giaTri); // Them node tu v2
            v2 = v2->tiep;
        } else if (v2 == nullptr || v1->chiSo < v2->chiSo) {
            themNode(ketQua, v1->chiSo, v1->giaTri); // Them node tu v1
            v1 = v1->tiep;
        } else {
            double tong = v1->giaTri + v2->giaTri; // Cong hai gia tri
            if (tong != 0) themNode(ketQua, v1->chiSo, tong); // Chi them neu khac 0
            v1 = v1->tiep;
            v2 = v2->tiep;
        }
    }
    return ketQua; // Tra ve danh sach ket qua
}

// Nhan vector thua voi mot so
Node* nhanVoSo(Node* v, double so) {
    Node* ketQua = nullptr; // Khoi tao danh sach ket qua rong
    while (v != nullptr) { // Duyet qua danh sach
        themNode(ketQua, v->chiSo, v->giaTri * so); // Nhan va them vao danh sach moi
        v = v->tiep;
    }
    return ketQua; // Tra ve danh sach ket qua
}

// Tich vo huong cua hai vector thua
double tichVoHuong(Node* v1, Node* v2) {
    double ketQua = 0; // Khoi tao gia tri ket qua = 0
    while (v1 != nullptr && v2 != nullptr) { // Duyet qua hai danh sach
        if (v1->chiSo < v2->chiSo) {
            v1 = v1->tiep;
        } else if (v1->chiSo > v2->chiSo) {
            v2 = v2->tiep;
        } else {
            ketQua += v1->giaTri * v2->giaTri; // Nhan va cong vao ket qua
            v1 = v1->tiep;
            v2 = v2->tiep;
        }
    }
    return ketQua; // Tra ve ket qua tich vo huong
}

// Tinh mo dun (do dai) cua vector thua
double moDun(Node* v) {
    double tong = 0; // Khoi tao tong binh phuong = 0
    while (v != nullptr) { // Duyet qua danh sach
        tong += v->giaTri * v->giaTri; // Cong binh phuong tung gia tri
        v = v->tiep;
    }
    return sqrt(tong); // Can bac hai va tra ve ket qua
}

// In vector thua ra man hinh
void inVectorThua(Node* v) {
    while (v != nullptr) { // Duyet qua danh sach
        cout << "(" << v->chiSo << ", " << v->giaTri << ") "; // In ra gia tri
        v = v->tiep;
    }
    cout << endl;
}

// Giai phong bo nho cap phat dong
void giaiPhong(Node*& dau) {
    while (dau != nullptr) { // Duyet va xoa tung node
        Node* tam = dau;
        dau = dau->tiep;
        delete tam;
    }
}

int main() {
    vector<double> vec = {3, 0, 4, 0, 0, -2}; // Khoi tao vector thuong
    vector<double> vec2 = {0, 5, -4, 0, 0, 3}; // Khoi tao vector thuong thu hai

    Node* v1 = chuyenThanhVectorThua(vec); // Chuyen thanh vector thua
    Node* v2 = chuyenThanhVectorThua(vec2);

    cout << "Vector v1 (thua): ";
    inVectorThua(v1);
    cout << "Vector v2 (thua): ";
    inVectorThua(v2);

    Node* tong = congVectorThua(v1, v2); // Cong hai vector thua
    cout << "Tong hai vector: ";
    inVectorThua(tong);

    giaiPhong(v1); giaiPhong(v2); giaiPhong(tong);
    return 0;
}
