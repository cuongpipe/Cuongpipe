#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void siftDown(int arr[], int i, int n)
{
    int maxIndex = i;
    int left = 2*i + 1;
    int right = 2*i + 2;
    if (left < n && arr[left] > arr[maxIndex])
        maxIndex = left;
    if (right < n && arr[right] > arr[maxIndex])
        maxIndex = right;
    if (i != maxIndex)
    {
        swap(arr[i], arr[maxIndex]);
        siftDown(arr, maxIndex, n);
    }
}

void heapSort(int arr[], int n)
{
    for (int i = n/2 -1; i >= 0; i--)
        siftDown(arr, i, n);

    for (int i = n-1; i >= 0; i--)
    {
        swap(arr[0], arr[i]);
        siftDown(arr, 0, i);
    }
}

void randomArr(int a[], int n)
{
    for (int i = 0; i < n; i++)
        a[i] = rand();
}

int main()
{
    int arr[1000], n = 1000;
    srand(time(NULL));
    randomArr(arr, n);
    heapSort(arr, n);
    cout << "Sorted array is \n";
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    return 0;
}
