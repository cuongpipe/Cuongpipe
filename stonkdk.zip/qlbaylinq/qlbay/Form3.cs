﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static qlbay.Form3;

namespace qlbay
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
            dtp_tgdat .CustomFormat = "dd/MM/yyyy HH:mm";
            dtp_tgdat.ShowUpDown = true;
            LoadComboBoxMakh();
            thôngTinĐặtVéToolStripMenuItem.ForeColor = Color.Blue;
            //ẩn tổng số tiền trước
           // label_tongsotiendat.Visible = false;
        }

        [Table(Name = "datve")]

        public class datve
        {
            [Column(IsPrimaryKey = true, Name = "idkhach")]
            public int idkhach { get; set; }
            
            [Column(Name = "machuyen")]
            public string machuyen { get; set; }
           
            [Column(Name = "giatien")]
            public double giatien { get; set; }
            
            [Column(Name = "thoigiandatve")]
            public DateTime thoigiandatve { get; set; }
        }


        [Table(Name = "khach")]

        public class khach
        {
            [Column(IsPrimaryKey = true, Name = "idkhach")]
            public int idkhach { get; set; }
            
            [Column(Name = "hoten")]
            public string hoten { get; set; }
            
            [Column(Name = "diachi")]
            public string diachi { get; set; }
            
            [Column(Name = "dienthoai")]
            public string dienthoai { get; set; }
        }

        private class QLCBDataContext : DataContext
        {
            public QLCBDataContext(string connection) : base(connection) { }
            public Table<datve> datves;
            public Table<khach> khachs;
        }

        private void cb_loc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedName = cb_loc.SelectedItem.ToString();
            FilterByTenNhanVien(selectedName);
        }


        //xử lý sự kiện khi chọn một khách hàng trong combobox
        private void LoadComboBoxMakh()
        {
            string connStr= "Data Source =xr;Initial Catalog=qlbay;Integrated Security=True;";
            //chỉ lấy các idkhach 1 lần duy nhất thui

           

            cb_loc.Items.Clear();
            cb_loc.Items.Add("Tất cả");

            using ( QLCBDataContext db = new QLCBDataContext(connStr))
            {
                //chỉ lấy mỗi khách 1 lần
                var query = (from dv in db.datves
                             select dv.idkhach).Distinct();



                foreach (var id in query)
                {
                    cb_loc.Items.Add(id.ToString());
                }
            }

            cb_loc.SelectedIndex = 0;
        }


        private void LoadData()
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                string sql = "SELECT * FROM datve";
                SqlDataAdapter gridviu = new SqlDataAdapter(sql, conn);
                gridviu.Fill(dt);
                grid_datve.RowHeadersVisible = false;
                grid_datve.DataSource = dt;
                //vứt dòng trống cuối cùng
                grid_datve.AllowUserToAddRows = false;
            }
            LoadComboBoxMakh();

            

        }


        //lọc theo id khách hàng và hiện lên grid view
        private void FilterByTenNhanVien(string idkhach)
        {
            string connStr = "Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;";
            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {
                List<object> ketQua;

                if (idkhach == "Tất cả")
                {
                    var query = from dv in db.datves
                                select new
                                {
                                    dv.idkhach,
                                    dv.machuyen,
                                    dv.giatien,
                                    dv.thoigiandatve
                                };
                    ketQua = query.ToList<object>();
                }
                else
                {
                    int id = int.Parse(idkhach);
                    var query = from dv in db.datves
                                where dv.idkhach == id
                                select new
                                {
                                    dv.idkhach,
                                    dv.machuyen,
                                    dv.giatien,
                                    dv.thoigiandatve
                                };

                    ketQua = query.ToList<object>();

                    // Tính tổng tiền
                    var tongTien = (from dv in db.datves
                                    where dv.idkhach == id
                                    select dv.giatien).Sum();

                    label_tongsotiendat.Text = tongTien.ToString("N0") + " VND";
                }

                grid_datve.DataSource = null; // quan trọng để tránh giữ trạng thái cũ
                grid_datve.RowHeadersVisible = false;
                grid_datve.AllowUserToAddRows = false;
                grid_datve.DataSource = ketQua;

                if (grid_datve.Columns.Contains("thoigiandatve"))
                    grid_datve.Columns["thoigiandatve"].Width = 200;
            }
        }







        private void btn_them_Click(object sender, EventArgs e)
        {
            // Kiểm tra ID hợp lệ phải là số nguyên. nếu idkhach là số nguyên thì tiếp tục hihi
            if (!int.TryParse(txt_idkhach.Text, out int idkhach))
            {
                MessageBox.Show("ID khách phải là số nguyên!");
                return;
            }

            string machuyen = txt_machuyen.Text.Trim();
            double giatien = txt_giatien.Text.Trim() == "" ? 0 : double.Parse(txt_giatien.Text.Trim());
            // string dt_tgdat = dtp_tgdat.Value.ToString("dd/MM/yyyy HH:mm"); // lấy ngày và giờ luôn
            DateTime dt_tgdat = dtp_tgdat.Value;

            //kiểm tra id khách và họ tên đã được nhập chưa 
            if (idkhach == 0 || string.IsNullOrEmpty(machuyen))
            {
                MessageBox.Show("id khách và mã chuyến không được để trống!");
                return;
            }

            string connStr = "Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;";
            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {

 
                //cho 1 khách đặt 1 chuyến nhiều lần

                // Tạo đối tượng mới
                datve dv = new datve
                {
                    idkhach = idkhach,
                    machuyen = machuyen,
                    giatien = giatien,
                    thoigiandatve = dt_tgdat //nó tự nhận thoigiandatve là datetime
                };

                // Thêm vào bảng
                db.datves.InsertOnSubmit(dv);

                // Thực hiện lưu vào DB
                db.SubmitChanges();


                MessageBox.Show("đã thêm thành công");
                cleartextbox();
                //LoadData(); // hiện tất cả ra bảng
              //  cb_loc.SelectedIndex = idkhach; // chỉ áp dụng cho idkhach là int
                FilterByTenNhanVien(idkhach.ToString());
                //conn.Close();
            }
        }

        private void cleartextbox()
        {
            txt_giatien.Text = "";
            txt_idkhach.Text = "";
            txt_machuyen.Text = "";
        }


        private void thôngTinKháchĐặtVéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide(); // hoặc this.Close();

        }
    }
}
