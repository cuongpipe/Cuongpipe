#include<iostream>
#include <fstream>
using namespace std;
// khai bao to chuc du lieu
struct Word {
	string english;
	string vietnamese;
};
struct EngVietDict {
	Word data;
	EngVietDict *left, *right;
};
//a) them 1 tu vao cay tu dien
//Insert a word into dict
void insertWord(EngVietDict *&root, Word data) {
	if (root == NULL) {
		root = new EngVietDict;
		root->data = data;
		root->left = root->right = NULL;
	} else if (data.english < root->data.english) {
		insertWord(root->left, data);
	} else if (data.english > root->data.english) {
		insertWord(root->right, data);
	}
}
//b) doc tu dien tu tep
//Read dictionary from text file
void readDictFromFile(EngVietDict *&root, string fileName) {
	ifstream file(fileName);
	string line;
	while (getline(file, line)) {
		int pos = line.find(':');
		string eng = line.substr(0, pos);
		string viet = line.substr(pos + 1);
		Word data = {eng, viet};
		insertWord(root, data);
	}
	file.close();
}
//c) in tu dien
//Print the dictionary ascending by english
void printDict(EngVietDict *root) {
	if (root) {
		printDict(root->left);
		cout <<root->data.english<<" : "<<root->data.vietnamese<< endl;
		printDict(root->right);
	}
}
//d) thao tac tra tu
//find the vietnamese from english
string findVietnamese(EngVietDict *root, string eng) {
	if (root == NULL) {
		return "";
	}
	if (root->data.english == eng) {
		return root->data.vietnamese;
	}
	if (eng < root->data.english) {
		return findVietnamese(root->left, eng);
	} else {
		return findVietnamese(root->right, eng);
	}
}
//e) xoa mot tu trong cay tu dien
EngVietDict *findMin(EngVietDict *root) {
	if (root->left == NULL) {
		return root;
	}
	return findMin(root->left);
}
void deleteWord(EngVietDict *&root, string eng) {
	if (root == NULL) {
		return;
	}
	if (eng < root->data.english) {
		deleteWord(root->left, eng);
	} else if (eng > root->data.english) {
		deleteWord(root->right, eng);
	} else {
		if (root->left == NULL && root->right == NULL) {
			delete root;
			root = NULL;
		} else if (root->left == NULL) {
			EngVietDict *temp = root;
			root = root->right;
			delete temp;
		} else if (root->right == NULL) {
			EngVietDict *temp = root;
			root = root->left;
			delete temp;
		} else {
			EngVietDict *temp = findMin(root->right);
			root->data = temp->data;
			deleteWord(root->right, temp->data.english);
		}
	}
}
//f)in len man hinh tu tieng anh va nghia tieng viet nhung tu tieng anh bat dau bang h co trong cay

void printWordByH(EngVietDict* root) {
	if (root) {
		printWordByH(root->left);
		if (!root->data.english.empty() && root->data.english[0] == 'h') {
			cout << root->data.english << " : " << root->data.vietnamese << endl;
		}
		printWordByH(root->right);
	}
}


//g) dem trong cay co bao nhieu tu sau tu t

int countAfterAWord(EngVietDict* root, string word) {
	if (root == NULL) {
		return 0;
	}
	if (root->data.english > word) {
		return 1 + countAfterAWord(root->left, word) + countAfterAWord(root->right, word);
	} else {
		return countAfterAWord(root->right, word);
	}
}



//h) luu tu dien vao tep van ban
void saveInOrder(EngVietDict* root, ofstream &file) {
	if (root) {
		saveInOrder(root->left, file);
		file << root->data.english << ":" << root->data.vietnamese << endl;
		saveInOrder(root->right, file);
	}
}

void saveDictToFile(EngVietDict* root, string fileName) {
	ofstream file(fileName);
	if (!file.is_open()) {
		cout << "Cannot open file to save.\n";
		return;
	}
	saveInOrder(root, file);
	file.close();
}


int main() {
	EngVietDict *root=NULL;
	string eng, viet;
	
	//doc tu file
	readDictFromFile(root, "EVD.txt");
	// in tu dien
	printDict(root);
	
	//tim ten tieng anh	
	cout << "Input a english " ;
	cin >> eng;
	viet = findVietnamese(root, eng);
	if (viet!="")
		cout << eng << ": " << viet << endl;
	else
		cout << eng << " not found in dictionary." << endl;
	
	//xoa Hello trong tu dien
	string tuxoa = "Hello";
	deleteWord(root, tuxoa);
	cout <<"tu dien sau khi xoa"<<" '"<< tuxoa <<"' "<< endl;
	printDict(root);

	cout << "\nWords starting with 'h':\n";
	printWordByH(root);

	cout << "\nNumber of words after 't': " << countAfterAWord(root, "t") << endl;

	saveDictToFile(root, "EVD_saved.txt");
	cout << "\nDictionary saved to EVD_saved.txt\n";


	return 0;

}