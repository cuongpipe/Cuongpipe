﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static qlcb.Form1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace qlcb
{
    public partial class Form2: Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadcbData();
        }

        //bảng cán bộ
        [Table(Name = "CanBo")]
        public class CanBo
        {
            [Column(IsPrimaryKey = true)]
            public int MaSo { get; set; }

            [Column]
            public string HoTen { get; set; }

            [Column]
            public int MaDonVi { get; set; }

            [Column]
            public int MaNgach { get; set; }

            [Column]
            public DateTime NgaySinh { get; set; }

            [Column]
            public string GioiTinh { get; set; }

            [Column]
            public double HeSoLuong { get; set; }
        }

        //bảng đơn vị
        [Table(Name = "DonVi")]
        public class DonVi
        {
            [Column(IsPrimaryKey = true)]
            public int MaDonVi { get; set; }

            [Column]
            public string TenDonVi { get; set; }
        }

        //bảng ngạch công tác
        [Table(Name = "NgachCongTac")]
        public class NgachCongTac
        {
            [Column(IsPrimaryKey = true)]
            public int MaNgach { get; set; }

            [Column]
            public string TenNgach { get; set; }
        }



        public class QLCBDataContext : DataContext
        {
            public QLCBDataContext(string connection) : base(connection) { }
            public Table<CanBo> CanBos;
            public Table<DonVi> DonVis;
            public Table<NgachCongTac> NgachCongTacs;

        }


        //Được gọi ngay khi mở Form. Hiển thị toàn bộ cán bộ

       // Đồng thời load danh sách mã số vào ComboBox để chuẩn bị cho người dùng lọc


        public void LoadcbData()
        {
            string connStr = @"Data Source=XR;Initial Catalog=qlcb;Integrated Security=True";
            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {
                var results = from cb in db.CanBos
                              join dv in db.DonVis on cb.MaDonVi equals dv.MaDonVi
                              join ntc in db.NgachCongTacs on cb.MaNgach equals ntc.MaNgach
                              select new
                              {
                                  cb.MaSo,
                                  cb.HoTen,
                                  cb.NgaySinh,
                                  cb.GioiTinh,
                                  tendonvi = dv.TenDonVi,
                                  tenngach = ntc.TenNgach,
                                  cb.HeSoLuong
                              };

                grid_cb.RowHeadersVisible = false;
                grid_cb.DataSource = results.ToList();
                LoadComboBoxMaSo();
            }
        }

        //Chạy mỗi khi người dùng chọn lại mục trong ComboBox
        //Thực hiện truy vấn lọc dữ liệu dựa trên lựa chọn từ ComboBox, rồi hiển thị kết quả lên DataGridView.
        private void combo_cb_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedMaSo = combo_cb.SelectedItem.ToString(); //combo_cb.SelectedItem là lấy từ combo box hihi

            string connStr = @"Data Source=XR;Initial Catalog=qlcb;Integrated Security=True";
            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {
                //Bạn gán giá trị cho results trong 2 nhánh khác nhau(if/else)
               //Nếu bạn không khai báo trước, thì results sẽ không tồn tại ở ngoài if/else
                IQueryable<object> results;

                if (selectedMaSo == "Tất cả")
                {
                    results = from cb in db.CanBos
                              join dv in db.DonVis on cb.MaDonVi equals dv.MaDonVi
                              join ntc in db.NgachCongTacs on cb.MaNgach equals ntc.MaNgach
                              select new
                              {
                                  cb.MaSo,
                                  cb.HoTen,
                                  cb.NgaySinh,
                                  cb.GioiTinh,
                                  tendonvi = dv.TenDonVi,
                                  tenngach = ntc.TenNgach,
                                  cb.HeSoLuong
                              };
                }
                else
                {
                    results = from cb in db.CanBos
                              join dv in db.DonVis on cb.MaDonVi equals dv.MaDonVi
                              join ntc in db.NgachCongTacs on cb.MaNgach equals ntc.MaNgach
                              where cb.MaSo == int.Parse(selectedMaSo)
                              select new
                              {
                                  cb.MaSo,
                                  cb.HoTen,
                                  cb.NgaySinh,
                                  cb.GioiTinh,
                                  tendonvi = dv.TenDonVi,
                                  tenngach = ntc.TenNgach,
                                  cb.HeSoLuong
                              };
                }

                grid_cb.DataSource = results.ToList();
            }
        }


        //combo_cb_SelectedIndexChanged, bạn dùng mã số được chọn để lọc lại danh sách cán bộ
        private void LoadComboBoxMaSo()
        {
            string connStr = @"Data Source=XR;Initial Catalog=qlcb;Integrated Security=True";

            using (QLCBDataContext db = new QLCBDataContext(connStr))
            {
                // 1. Xóa tất cả item cũ trong ComboBox
                combo_cb.Items.Clear();

                // 2. Thêm mục "Tất cả" để xem tất cả cán bộ
                combo_cb.Items.Add("Tất cả");

                // 3. Truy vấn tất cả MaSo từ bảng CanBo
                var masoList = from cb in db.CanBos
                               select cb.MaSo;

                // 4. Thêm từng MaSo (kiểu int) vào ComboBox
                foreach (var maso in masoList)
                {
                    combo_cb.Items.Add(maso); // maso là int
                }
            }

            // 5. Mặc định chọn mục đầu tiên ("Tất cả")
            combo_cb.SelectedIndex = 0;
        }



        private void thôngTinLươngCánBộToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3(); // Tạo form mới
            form.ShowDialog(); // Hiển thị dưới dạng hộp thoại (chặn form chính)
        }



    }

}
