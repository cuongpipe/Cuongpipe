﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace qlbay
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadData();
            thôngTinKháchĐặtVéToolStripMenuItem.ForeColor = Color.Blue;
        }

        private void LoadData()
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                string sql = "SELECT * FROM khach";
                SqlDataAdapter gridviu = new SqlDataAdapter(sql, conn);
                gridviu.Fill(dt);
                grid_thongtin.RowHeadersVisible = false;
                grid_thongtin.DataSource = dt;
            }
            //load các tùy chọn trong combobox bằng hàm dưới
            LoadComboBoxMakh();
        }

        private void btn_them_Click(object sender, EventArgs e)
        {

            // Kiểm tra ID hợp lệ
            if (!int.TryParse(txt_idkhach.Text, out int idkhach))
            {
                MessageBox.Show("ID khách phải là số nguyên!");
                return;
            }

            string hoten = txt_hoten.Text.Trim();
            string dt_ngaysinh = dtp_ngaysinh.Value.ToString("yyyy-MM-dd"); // Không cần giờ phút giây nếu không cần
            string diachi = txt_diachi.Text.Trim();

            //khởi tạo cái biến gioitinh trống để lưu giói tính
            string gioitinh = "";
            if (rd_btn_nam.Checked)
            {
                gioitinh = "nam";
            }
            else if (rd_btn_nu.Checked)
            {
                gioitinh = "Nữ";
            }

            //kiểm tra id khách và họ tên đã được nhập chưa 
            if (idkhach == 0 || string.IsNullOrEmpty(hoten))
            {
                MessageBox.Show("id khách và Họ tên không được để trống!");
                return;
            }

            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                conn.Open();

                // Kiểm tra xem mã khách hàng đã tồn tại chưa
                string checkSql = "SELECT COUNT(*) FROM khach WHERE idkhach = @idkhach";
                SqlCommand checkCmd = new SqlCommand(checkSql, conn);
                checkCmd.Parameters.AddWithValue("@idkhach", idkhach);

                if ((int)checkCmd.ExecuteScalar() > 0)
                {
                    MessageBox.Show("Mã nhân viên đã tồn tại! Vui lòng nhập mã khác.");
                    conn.Close();
                    return;
                }

                // Nếu chưa tồn tại, thực hiện thêm mới
                //string query = @"";
                string sql = "INSERT into khach values('" + idkhach +
                "','" + hoten + "','" + dt_ngaysinh + "','" + diachi + "','" + gioitinh + "')";

                //
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("đã thêm thành công");
                LoadData();
                //conn.Close();
            }

            MessageBox.Show("in kq: " + dt_ngaysinh);

        }

        private void btn_capnhat_Click(object sender, EventArgs e)
        {

            //khởi tạo cái biến gioitinh trống . để lưu giói tính
            string gioitinh = "";
            if (rd_btn_nam.Checked)
            {
                gioitinh = "nam";
            }
            else if (rd_btn_nu.Checked)
            {
                gioitinh = "nữ";
            }

            if (string.IsNullOrEmpty(txt_idkhach.Text))
            {
                MessageBox.Show("Vui lòng chọn một nhân viên để sửa.");
                return;
            }

            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                // Kiểm tra xem mã khách hàng có tồn tại không
                string checkSql = "SELECT COUNT(*) FROM khach WHERE idkhach = @idkhach";
                SqlCommand checkCmd = new SqlCommand(checkSql, conn);
                checkCmd.Parameters.AddWithValue("@idkhach", txt_idkhach.Text);

                conn.Open();
                if ((int)checkCmd.ExecuteScalar() < 0)
                {
                    MessageBox.Show("Id khách không tồn tại! Vui lòng kiểm tra lại");
                    conn.Close();
                    
                }


                string sql = "UPDATE khach SET hoten = @hoten, NgaySinh = @ngaysinh,  diachi = @diachi, gioitinh = @gioitinh WHERE idkhach = @idkhach";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@idkhach", txt_idkhach.Text);
                cmd.Parameters.AddWithValue("@hoten", txt_hoten.Text);
                cmd.Parameters.AddWithValue("@diachi", txt_diachi.Text);
                cmd.Parameters.AddWithValue("@ngaysinh", dtp_ngaysinh.Value);
                cmd.Parameters.AddWithValue("@gioitinh", gioitinh);


                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Cập nhật nhân viên thành công!");
                LoadData();
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txt_idkhach.Text) || string.IsNullOrEmpty(txt_hoten.Text) ||
    string.IsNullOrEmpty(dtp_ngaysinh.Text) || string.IsNullOrEmpty(txt_diachi.Text))
            {
                MessageBox.Show("Vui lòng chọn khách hàng để xóa!");
                return;
            }

            SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;");
            string query = "DELETE FROM khach WHERE idkhach = @khach";

            try
            {

                // Kiểm tra xem mã khách hàng có tồn tại không
                string checkSql = "SELECT COUNT(*) FROM khach WHERE idkhach = @idkhach";
                SqlCommand checkCmd = new SqlCommand(checkSql, conn);
                checkCmd.Parameters.AddWithValue("@idkhach", txt_idkhach.Text);

                if ((int)checkCmd.ExecuteScalar() < 0)
                {
                    MessageBox.Show("Id khách không tồn tại! Vui lòng kiểm tra lại");
                    conn.Close();

                }

                DialogResult r = MessageBox.Show("Xác nhận xoá khách này?", "Xác nhận", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@idkhach", txt_idkhach.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công");
                    LoadData(); // Nếu muốn cập nhật lại lưới
                    conn.Close();
                }
                else
                {
                    MessageBox.Show("Xóa đã bị hủy.");
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message);
            }
        }

        private void grid_thongtin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= grid_thongtin.Rows.Count)
                return; // Không làm gì nếu click ngoài vùng hợp lệ vd: nhấn vô ô tiêu đề của cột!
            DataGridViewRow row = grid_thongtin.Rows[e.RowIndex];
            txt_idkhach.Text = row.Cells["idkhach"].Value.ToString();
            txt_hoten.Text = row.Cells["HoTen"].Value.ToString();
            dtp_ngaysinh.Value = Convert.ToDateTime(row.Cells["NgaySinh"].Value);
            txt_diachi.Text = row.Cells["DiaChi"].Value.ToString();

            if ((row.Cells["gioitinh"].Value.ToString()) == "nam")
            {
                rd_btn_nam.Checked = true; 
            }
            else if ((row.Cells["gioitinh"].Value.ToString()) == "nữ")
            {
                rd_btn_nu.Checked = true;
            }


        }






        // tải dữ liệu vào combo để chọn
        private void LoadComboBoxMakh()
        {
            string connectionString = "Data Source=xr;Initial Catalog=qlbay;Integrated Security=True;";
            string query = "SELECT idkhach FROM khach";

            cb_loc.Items.Clear();
            cb_loc.Items.Add("Tất cả");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cb_loc.Items.Add(reader["idkhach"].ToString());
                }
            }

            cb_loc.SelectedIndex = 0;
        }






        //lọc theo id khách hàng và hiện lên grid view
        private void FilterByTenNhanVien(string idkhach)
        {
            using (SqlConnection conn = new SqlConnection("Data Source = xr; Initial Catalog = qlbay; Integrated Security = True;"))
            {
                string sql;

                if (idkhach == "Tất cả")
                {
                    sql = "SELECT * FROM khach";
                }
                else
                {
                    sql = "SELECT * FROM khach WHERE idkhach = @idkhach";
                    //sql = "SELECT MaNV, HoTen, DiaChi, FORMAT(NgaySinh, 'dd/MM/yyyy') AS NgaySinh, DienThoai FROM nhanvien WHERE HoTen = @HoTen";
                }

                SqlCommand cmd = new SqlCommand(sql, conn);
                if (idkhach != "Tất cả")
                    cmd.Parameters.AddWithValue("@idkhach", idkhach);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                grid_thongtin .RowHeadersVisible = false; // ẩn cột lỏ đầu tiên
                adapter.Fill(dt);
                grid_thongtin .DataSource = dt;
            }
        }



        //xử lý sự kiện khi chọn một khách hàng trong combobox
        private void cb_loc_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedName = cb_loc.SelectedItem.ToString();
            FilterByTenNhanVien(selectedName);
        }

        private void thôngTinĐặtVéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //làm biến mất các nút thừa thãi
            //cb_loc.Visible = false;
            //label6.Visible = false;
      
            Form3 f3 = new Form3();
            f3.ShowDialog();
            this.Hide(); // hoặc this.Close();
            //this.Close();

        }
    }
}
