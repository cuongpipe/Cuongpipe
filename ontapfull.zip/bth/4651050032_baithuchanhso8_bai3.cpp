#include <iostream>
#include <queue>
#include <vector>
using namespace std;

// Bo sung: Ham so sanh theo yeu cau b
struct Compare {
    bool operator()(int a, int b) {
        // a chan, b le: a uu tien => false
        if (a % 2 == 0 && b % 2 != 0) return false;
        // a le, b chan: b uu tien => true
        if (a % 2 != 0 && b % 2 == 0) return true;
        // Cung loai: so lon dung truoc
        return a < b;
    }
};

int main()
{
    int arr[6] = { 10, 2, 4, 8, 6, 9 };

    // priority_queue<int, vector<int>, greater<int>> pq;

    // Su dung ham so sanh de uu tien so chan truoc so le
    priority_queue<int, vector<int>, Compare> pq;

    // In mang ban dau
    cout << "Mang ban dau: ";
    for (auto i : arr) {
        cout << i << ' ';
    }
    cout << endl;

    // Day cac phan tu vao priority_queue
    for (int i = 0; i < 6; i++) {
        pq.push(arr[i]);
    }

    // In ra thu tu lay cac phan tu tu priority_queue
    cout << "Hang doi uu tien (chan truoc, trong nhom giam dan): ";
    while (!pq.empty()) {
        cout << pq.top() << ' ';
        pq.pop();
    }

    return 0;
}
